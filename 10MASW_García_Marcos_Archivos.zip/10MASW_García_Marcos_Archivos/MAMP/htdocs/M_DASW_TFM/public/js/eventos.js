
// Al pulsar sobre el toggle "Créditos:" se activa/para un audio:

let creditos = document.querySelector("details.creditos");

let autoaudio = document.getElementById("autoaudio");
let sonando = false; // Guarda el estado (memoria) de activación del audio.

autoaudio.src="https://cdn.pixabay.com/audio/2022/01/14/audio_765bb2a81b.mp3";
autoaudio.controls=true;
autoaudio.loop = true;

creditos.addEventListener("toggle", function() {
    
    if (sonando == false) {
        autoaudio.play();
        sonando = true; 
    } else {
        autoaudio.pause();
        sonando = false;
    }

})
