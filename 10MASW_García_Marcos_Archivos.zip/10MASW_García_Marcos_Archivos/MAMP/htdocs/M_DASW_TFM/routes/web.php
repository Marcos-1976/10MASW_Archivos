<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

// Ruta creada por defecto en el "web.php" asociada a la URL "welcome" de la aplicación Web (/).
Route::get('/', function () {
    return view('welcome');
});
// Se llama a la vista "welcome.blade.php" que se encuentra en el directorio "/public", con el nombre "welcome".
Route::view('/', 'welcome')->name('welcome');

// Es una clase de ayuda a generar todas las rutas requeridas para la autenticación del usuario.
Auth::routes();
// Se llama al controlador "HomeController.php" al se le pasa el parámetro "logout" que se encuentra en el directorio "/app/Http/Controllers", con el nombre "logout".
Route::get('/logout', 'HomeController@logout')->name('logout');

// Se llama al controlador "HomeController.php" al se le pasa el parámetro "index" que se encuentra en el directorio "/app/Http/Controllers", con el nombre "home".
Route::get('/home', 'HomeController@index')->name('home');

// Se agrupan URLs en un mismo grupo que comparten parte de la URL y utilizan el mismo middleware.
Route::prefix('clientes')->group(function () {
    Route::match(['get', 'post'], '/', 'ClienteController@index')->middleware('auth')->name('clientes.index');
    Route::get('/create', 'ClienteController@create')->middleware('auth')->name('clientes.create');
    Route::post('/store', 'ClienteController@store')->middleware('auth')->name('clientes.store');
    Route::get('/{cliente}/edit', 'ClienteController@edit')->middleware('auth')->name('clientes.edit');
    Route::post('/{cliente}/update', 'ClienteController@update')->middleware('auth')->name('clientes.update');
    Route::delete('/{cliente}/delete', 'ClienteController@delete')->middleware('auth')->name('clientes.delete');
});

Route::prefix('lugars')->group(function () {
    Route::match(['get', 'post'], '/', 'LugarController@index')->middleware('auth')->name('lugars.index');
    Route::get('/create', 'LugarController@create')->middleware('auth')->name('lugars.create');
    Route::post('/store', 'LugarController@store')->middleware('auth')->name('lugars.store');
    Route::get('/{lugar}/edit', 'LugarController@edit')->middleware('auth')->name('lugars.edit');
    Route::post('/{lugar}/update', 'LugarController@update')->middleware('auth')->name('lugars.update');
    Route::delete('/{lugar}/delete', 'LugarController@delete')->middleware('auth')->name('lugars.delete');
});

Route::prefix('compras')->group(function () {
    Route::match(['get', 'post'], '/', 'CompraController@index')->middleware('auth')->name('compras.index');
    Route::get('/create', 'CompraController@create')->middleware('auth')->name('compras.create');
    Route::post('/store', 'CompraController@store')->middleware('auth')->name('compras.store');
    Route::get('/{compra}/edit', 'CompraController@edit')->middleware('auth')->name('compras.edit');
    Route::post('/{compra}/update', 'CompraController@update')->middleware('auth')->name('compras.update');
    Route::delete('/{compra}/delete', 'CompraController@delete')->middleware('auth')->name('compras.delete');
});

Route::prefix('polizas')->group(function () {
    Route::match(['get', 'post'], '/', 'PolizaController@index')->middleware('auth')->name('polizas.index');
    Route::get('/create', 'PolizaController@create')->middleware('auth')->name('polizas.create');
    Route::post('/store', 'PolizaController@store')->middleware('auth')->name('polizas.store');
    Route::get('/{poliza}/edit', 'PolizaController@edit')->middleware('auth')->name('polizas.edit');
    Route::post('/{poliza}/update', 'PolizaController@update')->middleware('auth')->name('polizas.update');
    Route::delete('/{poliza}/delete', 'PolizaController@delete')->middleware('auth')->name('polizas.delete');
});

Route::prefix('aseguras')->group(function () {
    Route::match(['get', 'post'], '/', 'AseguraController@index')->middleware('auth')->name('aseguras.index');
    Route::get('/create', 'AseguraController@create')->middleware('auth')->name('aseguras.create');
    Route::post('/store', 'AseguraController@store')->middleware('auth')->name('aseguras.store');
    Route::get('/{asegura}/edit', 'AseguraController@edit')->middleware('auth')->name('aseguras.edit');
    Route::post('/{asegura}/update', 'AseguraController@update')->middleware('auth')->name('aseguras.update');
    Route::delete('/{asegura}/delete', 'AseguraController@delete')->middleware('auth')->name('aseguras.delete');
});

Route::prefix('vehiculos')->group(function () {
    Route::match(['get', 'post'], '/', 'VehiculoController@index')->middleware('auth')->name('vehiculos.index');
    Route::get('/create', 'VehiculoController@create')->middleware('auth')->name('vehiculos.create');
    Route::post('/store', 'VehiculoController@store')->middleware('auth')->name('vehiculos.store');
    Route::get('/{vehiculo}/edit', 'VehiculoController@edit')->middleware('auth')->name('vehiculos.edit');
    Route::post('/{vehiculo}/update', 'VehiculoController@update')->middleware('auth')->name('vehiculos.update');
    Route::delete('/{vehiculo}/delete', 'VehiculoController@delete')->middleware('auth')->name('vehiculos.delete');
});

Route::prefix('modelos')->group(function () {
    Route::match(['get', 'post'], '/', 'ModeloController@index')->middleware('auth')->name('modelos.index');
    Route::get('/create', 'ModeloController@create')->middleware('auth')->name('modelos.create');
    Route::post('/store', 'ModeloController@store')->middleware('auth')->name('modelos.store');
    Route::get('/{modelo}/edit', 'ModeloController@edit')->middleware('auth')->name('modelos.edit');
    Route::post('/{modelo}/update', 'ModeloController@update')->middleware('auth')->name('modelos.update');
    Route::delete('/{modelo}/delete', 'ModeloController@delete')->middleware('auth')->name('modelos.delete');
});

Route::prefix('hatenidos')->group(function () {
    Route::match(['get', 'post'], '/', 'HatenidoController@index')->middleware('auth')->name('hatenidos.index');
    Route::get('/create', 'HatenidoController@create')->middleware('auth')->name('hatenidos.create');
    Route::post('/store', 'HatenidoController@store')->middleware('auth')->name('hatenidos.store');
    Route::get('/{hatenido}/edit', 'HatenidoController@edit')->middleware('auth')->name('hatenidos.edit');
    Route::post('/{hatenido}/update', 'HatenidoController@update')->middleware('auth')->name('hatenidos.update');
    Route::delete('/{hatenido}/delete', 'HatenidoController@delete')->middleware('auth')->name('hatenidos.delete');
});

Route::prefix('accidentes')->group(function () {
    Route::match(['get', 'post'], '/', 'AccidenteController@index')->middleware('auth')->name('accidentes.index');
    Route::get('/create', 'AccidenteController@create')->middleware('auth')->name('accidentes.create');
    Route::post('/store', 'AccidenteController@store')->middleware('auth')->name('accidentes.store');
    Route::get('/{accidente}/edit', 'AccidenteController@edit')->middleware('auth')->name('accidentes.edit');
    Route::post('/{accidente}/update', 'AccidenteController@update')->middleware('auth')->name('accidentes.update');
    Route::delete('/{accidente}/delete', 'AccidenteController@delete')->middleware('auth')->name('accidentes.delete');
});
