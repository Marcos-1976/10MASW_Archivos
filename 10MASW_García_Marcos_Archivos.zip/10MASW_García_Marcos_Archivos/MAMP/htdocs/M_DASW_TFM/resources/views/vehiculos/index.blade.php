@extends('layouts.main')

@section('title')
    {{__('strings.vehiculo_index_title')}}
@endsection

@section('content')

<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1>{{__('strings.vehiculo_index_title')}}</h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="{{ route('vehiculos.create') }}">{{__('strings.vehiculo_create_btn')}}&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        @csrf
                        <label for="vehiculoMatricula" class="form-label">{{__('strings.matricula_header')}}</label>
                        <input id="vehiculoMatricula" name="vehiculoMatricula" class="form-control" value="@isset($vehiculoMatricula) {{$vehiculoMatricula}} @endisset" placeholder="{{__('strings.search_matricula_placeholder')}}" />
                        
                        <label for="vehiculoFechaMatricula" class="form-label">{{__('strings.fechaMatricula_header')}}</label>
                        <input id="vehiculoFechaMatricula" name="vehiculoFechaMatricula" class="form-control" value="@isset($vehiculoFechaMatricula) {{$vehiculoFechaMatricula}} @endisset" placeholder="{{__('strings.search_fechaMatricula_placeholder')}}" />
                        
                        <label for="vehiculoColor" class="form-label">{{__('strings.color_header')}}</label>
                        <input id="vehiculoColor" name="vehiculoColor" class="form-control" value="@isset($vehiculoColor) {{$vehiculoColor}} @endisset" placeholder="{{__('strings.search_color_placeholder')}}" />

                        <label for="vehiculoPrecio" class="form-label">{{__('strings.precio_header')}}</label>
                        <input id="vehiculoPrecio" name="vehiculoPrecio" class="form-control" value="@isset($vehiculoPrecio) {{$vehiculoPrecio}} @endisset" placeholder="{{__('strings.search_precio_placeholder')}}" />

                        <label for="vehiculoKilometraje" class="form-label">{{__('strings.kilometraje_header')}}</label>
                        <input id="vehiculoKilometraje" name="vehiculoKilometraje" class="form-control" value="@isset($vehiculoKilometraje) {{$vehiculoKilometraje}} @endisset" placeholder="{{__('strings.search_kilometraje_placeholder')}}" />

                        <label for="vehiculoAntecedentes" class="form-label">{{__('strings.antecedentes_header')}}</label>
                        <input id="vehiculoAntecedentes" name="vehiculoAntecedentes" class="form-control" value="@isset($vehiculoAntecedentes) {{$vehiculoAntecedentes}} @endisset" placeholder="{{__('strings.search_antecedentes_placeholder')}}" />

                        <label for="vehiculoIdModelo" class="form-label">{{__('strings.idModelo_header')}}</label>
                        <select id="vehiculoIdModelo" name="vehiculoIdModelo" class="form-select">
                            <option value="-1" selected>{{__('strings.search_idModelo_placeholder')}}</option>
                            @foreach($modelos as $modelo)
                                @if($vehiculoIdModelo == $modelo->idModelo) {{-- Nombre del campo en la BD. --}}
                                    <option value="{{$modelo->idModelo}}" selected>{{$modelo->idModelo}}</option>
                                @else
                                    <option value="{{$modelo->idModelo}}">{{$modelo->idModelo}}</option>
                                @endif
                            @endforeach
                        </select>

                        <button type="submit" class="btn btn-primary my-2">{{__('strings.search_btn')}}</button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    @if(count($vehiculos) > 0)
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th>{{__('strings.matricula_header')}}</th>
                                <th>{{__('strings.fechaMatricula_header')}}</th>
                                <th>{{__('strings.color_header')}}</th>
                                <th>{{__('strings.precio_header')}}</th>
                                <th>{{__('strings.kilometraje_header')}}</th>
                                <th>{{__('strings.antecedentes_header')}}</th>
                                <th>{{__('strings.idModelo_header')}}</th>
                                <th>{{__('strings.actions_header')}}</th>
                            </thead>
                            <tbody>
                            @foreach($vehiculos as $vehiculo)
                                <tr>
                                    <td>{{$vehiculo->matricula}}</td>
                                    <td>{{$vehiculo->fechaMatricula}}</td>
                                    <td>{{$vehiculo->color}}</td>
                                    <td>{{$vehiculo->precio}}</td>
                                    <td>{{$vehiculo->kilometraje}}</td>
                                    <td>{{$vehiculo->antecedentes}}</td>
                                    <td>{{$vehiculo->modelo->idModelo.' '.$vehiculo->modelo->tipoCarroceria}}</td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Poliza">
                                            <a class="btn btn-success" href="{{ route('vehiculos.edit', $vehiculo) }}">{{__('strings.edit_btn')}}</a>&nbsp;&nbsp;
                                            <form name="delete-form-{{$vehiculo->matricula}}" action="{{ route('vehiculos.delete', $vehiculo) }}" method="post" style="display: inline-block;">
                                                {{ method_field('delete') }}
                                                {{ csrf_field() }}
                                                <button type="submit" class="btn btn-danger">{{__('strings.delete_btn')}}</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="alert alert-warning mt-3">
                            {{__('strings.no_vehiculos')}}
                        </div>
                    @endif
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                {{ $vehiculos->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
