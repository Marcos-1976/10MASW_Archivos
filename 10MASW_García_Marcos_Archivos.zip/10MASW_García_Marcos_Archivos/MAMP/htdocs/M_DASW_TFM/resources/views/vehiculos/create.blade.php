@extends('layouts.main')

@section('title')
    @isset($vehiculo)
        {{__('strings.vehiculo_edit_title')}}
    @else
        {{__('strings.vehiculo_create_title')}}
    @endisset
@endsection

@section('content')
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    @isset($vehiculo)
                        <h1>{{__('strings.vehiculo_edit_title')}} {{$vehiculo->matricula}} {{$vehiculo->fechaMatricula}} {{$vehiculo->color}} {{$vehiculo->precio}} {{$vehiculo->kilometraje}} {{$vehiculo->antecedentes}} {{$vehiculo->idModelo}}</h1>
                    @else
                        <h1>{{__('strings.vehiculo_create_title')}}</h1>
                    @endisset
                </div>
            </div>
            <div class="card-body">
                @isset($vehiculo)
                    <form name="edit_vehiculo" action="{{ route('vehiculos.update', $vehiculo) }}" method="post">
                    @csrf
                @else
                    <form name="create_vehiculo" action="{{ route('vehiculos.store') }}" method="post">
                    @csrf
                @endisset
                    <div class="mb-3">
                        <label for="vehiculoMatricula" class="form-label"> {{__('strings.matricula_header')}}</label>
                        <input id="vehiculoMatricula" name="vehiculoMatricula" type="text" placeholder="{{__('strings.matricula_placeholder')}}"
                        class="form-control" required @isset($vehiculo) value="{{ old('vehiculoMatricula', $vehiculo->matricula)}}" @else value="{{ old('vehiculoMatricula') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="vehiculoFechaMatricula" class="form-label"> {{__('strings.fechaMatricula_header')}}</label>
                        <input id="vehiculoFechaMatricula" name="vehiculoFechaMatricula" type="text" placeholder="{{__('strings.fechaMatricula_placeholder')}}"
                        class="form-control" required @isset($vehiculo) value="{{ old('vehiculoFechaMatricula', $vehiculo->fechaMatricula)}}" @else value="{{ old('vehiculoFechaMatricula') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="vehiculoColor" class="form-label"> {{__('strings.color_header')}}</label>
                        <input id="vehiculoColor" name="vehiculoColor" type="text" placeholder="{{__('strings.color_placeholder')}}"
                        class="form-control" required @isset($vehiculo) value="{{ old('vehiculoColor', $vehiculo->color)}}" @else value="{{ old('vehiculoColor') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="vehiculoPrecio" class="form-label"> {{__('strings.precio_header')}}</label>
                        <input id="vehiculoPrecio" name="vehiculoPrecio" type="text" placeholder="{{__('strings.precio_placeholder')}}"
                        class="form-control" required @isset($vehiculo) value="{{ old('vehiculoPrecio', $vehiculo->precio)}}" @else value="{{ old('vehiculoPrecio') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="vehiculoKilometraje" class="form-label"> {{__('strings.kilometraje_header')}}</label>
                        <input id="vehiculoKilometraje" name="vehiculoKilometraje" type="text" placeholder="{{__('strings.kilometraje_placeholder')}}"
                        class="form-control" required @isset($vehiculo) value="{{ old('vehiculoKilometraje', $vehiculo->kilometraje)}}" @else value="{{ old('vehiculoKilometraje') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="vehiculoAntecedentes" class="form-label"> {{__('strings.antecedentes_header')}}</label>
                        <input id="vehiculoAntecedentes" name="vehiculoAntecedentes" type="text" placeholder="{{__('strings.antecedentes_placeholder')}}"
                        class="form-control" required @isset($vehiculo) value="{{ old('vehiculoAntecedentes', $vehiculo->antecedentes)}}" @else value="{{ old('vehiculoAntecedentes') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="vehiculoIdModelo" class="form-label">{{__('strings.idModelo_header')}}</label>
                        <select id="vehiculoIdModelo" name="vehiculoIdModelo" class="form-select">                            
                            @isset($vehiculo)
                                <option value="-1" selected>{{__('strings.search_idModelo_placeholder')}}</option>
                                @foreach($modelos as modelo)
                                    @if($vehiculo->idModelo == $modelo->idModelo)     
                                        <option value="{{$modelo->idModelo}}" selected>{{$modelo->idModelo}}</option>
                                    @else
                                        <option value="{{$modelo->idModelo}}">{{$modelo->idModelo}}</option>
                                    @endif
                                @endforeach
                            @else
                                <option value="-1" selected>{{__('strings.idModelo_placeholder')}}</option>
                                @foreach($modelos as $modelo)
                                    <option value="{{$modelo->idModelo}}">{{$modelo->idModelo}}</option>
                                @endforeach
                            @endisset
                        </select>
                    </div>
                    <input type="submit" value="@isset($vehiculo) {{__('strings.save_btn')}} @else {{__('strings.create_btn')}} @endisset" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
