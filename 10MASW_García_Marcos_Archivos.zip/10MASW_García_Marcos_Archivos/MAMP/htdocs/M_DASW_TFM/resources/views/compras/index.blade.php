@extends('layouts.main')

@section('title')
    {{__('strings.compra_index_title')}}
@endsection

@section('content')
{{--
<h1>{{__('strings.compra_index_title')}}</h1>
--}}

<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1>{{__('strings.compra_index_title')}}</h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="{{ route('compras.create') }}">{{__('strings.compra_create_btn')}}&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        @csrf
                        <label for="compraDNI" class="form-label">{{__('strings.DNI_header')}}</label>
                        <select id="compraDNI" name="compraDNI" class="form-select">
                            <option value="-1" selected>{{__('strings.search_DNI_placeholder')}}</option>
                            @foreach($clientes as $cliente)
                                @if($compraDNI == $cliente->DNI) {{-- Nombre del campo en la BD. --}}
                                    <option value="{{$cliente->DNI}}" selected>{{$cliente->DNI}}</option>
                                @else
                                    <option value="{{$cliente->DNI}}">{{$cliente->DNI}}</option>
                                @endif
                            @endforeach
                        </select>
                        
                        <label for="compraIdPoliza" class="form-label">{{__('strings.idPoliza_header')}}</label>
                        <select id="compraIdPoliza" name="compraIdPoliza" class="form-select">
                            <option value="-1" selected>{{__('strings.search_idPoliza_placeholder')}}</option>
                            @foreach($polizas as $poliza)
                                @if($compraIdPoliza == $poliza->idPoliza)
                                    <option value="{{$poliza->idPoliza}}" selected>{{$poliza->idPoliza}}</option>
                                @else
                                    <option value="{{$poliza->idPoliza}}">{{$poliza->idPoliza}}</option>
                                @endif
                            @endforeach
                        </select>
                        
                        <button type="submit" class="btn btn-primary my-2">{{__('strings.search_btn')}}</button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    @if(count($compras) > 0)
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th>{{__('strings.DNI_header')}}</th>
                                <th>{{__('strings.idPoliza_header')}}</th>
                                <th>{{__('strings.actions_header')}}</th>
                            </thead>
                            <tbody>
                            @foreach($compras as $compra)
                                <tr>
                                    <td>{{$compra->cliente->DNI.' - Nombre: '.$compra->cliente->nombre}}</td> {{-- Nombre del campo en la BD. --}}
                                    <td>{{$compra->poliza->idPoliza}}</td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Compra">
                                            <a class="btn btn-success" href="{{ route('compras.edit', $compra) }}">{{__('strings.edit_btn')}}</a>&nbsp;&nbsp;
                                            <form name="delete-form-{{$compra->DNI}}" action="{{ route('compras.delete', $compra) }}" method="post" style="display: inline-block;"> {{-- Nombre de la clave primaria en la BD. --}}
                                                {{ method_field('delete') }}
                                                {{ csrf_field() }}
                                                <button type="submit" class="btn btn-danger">{{__('strings.delete_btn')}}</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="alert alert-warning mt-3">
                            {{__('strings.no_compras')}}
                        </div>
                    @endif
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                {{ $compras->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
