@extends('layouts.main')

@section('title')
    @isset($compra)
        {{__('strings.compra_edit_title')}}
    @else
        {{__('strings.compra_create_title')}}
    @endisset
@endsection

@section('content')
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    @isset($compra)
                        <h1>{{__('strings.compra_edit_title')}} {{$compra->DNI}} {{$compra->idPoliza}}</h1> {{-- Nombre del campo en la BD. --}}
                    @else
                        <h1>{{__('strings.compra_create_title')}}</h1>
                    @endisset
                </div>
            </div>
            <div class="card-body">
                @isset($compra)
                    <form name="edit_compra" action="{{ route('compras.update', $compra) }}" method="post">
                    @csrf
                @else
                    <form name="create_compra" action="{{ route('compras.store') }}" method="post">
                    @csrf
                @endisset
                    <div class="mb-3">
                        <label for="compraDNI" class="form-label">{{__('strings.DNI_header')}}</label>
                        <select id="compraDNI" name="compraDNI" class="form-select">                            
                            @isset($compra)
                                <option value="-1" selected>{{__('strings.search_DNI_placeholder')}}</option>
                                @foreach($clientes as $cliente)
                                    @if($compra->DNI == $cliente->DNI)     
                                        <option value="{{$cliente->DNI}}" selected>{{$cliente->DNI}}</option>
                                    @else
                                        <option value="{{$cliente->DNI}}">{{$cliente->DNI}}</option>
                                    @endif
                                @endforeach
                            @else
                                <option value="-1" selected>{{__('strings.DNI_placeholder')}}</option>
                                @foreach($clientes as $cliente)
                                    <option value="{{$cliente->DNI}}">{{$cliente->DNI}}</option>
                                @endforeach
                            @endisset
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="compraIdPoliza" class="form-label">{{__('strings.idPoliza_header')}}</label>
                        <select id="compraIdPoliza" name="compraIdPoliza" class="form-select">                            
                            @isset($compra)
                                <option value="-1" selected>{{__('strings.search_idPoliza_placeholder')}}</option>
                                @foreach($polizas as $poliza)
                                    @if($compra->idPoliza == $poliza->idPoliza)     
                                        <option value="{{$poliza->idPoliza}}" selected>{{$poliza->idPoliza}}</option>
                                    @else
                                        <option value="{{$poliza->idPoliza}}">{{$poliza->idPoliza}}</option>
                                    @endif
                                @endforeach
                            @else
                                <option value="-1" selected>{{__('strings.idPoliza_placeholder')}}</option>
                                @foreach($polizas as $poliza)
                                    <option value="{{$poliza->idPoliza}}">{{$poliza->idPoliza}}</option>
                                @endforeach
                            @endisset
                        </select>
                    </div>
                    <input type="submit" value="@isset($compra) {{__('strings.save_btn')}} @else {{__('strings.create_btn')}} @endisset" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
