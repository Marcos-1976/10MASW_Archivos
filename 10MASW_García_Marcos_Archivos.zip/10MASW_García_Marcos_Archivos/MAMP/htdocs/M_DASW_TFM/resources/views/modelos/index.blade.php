@extends('layouts.main')

@section('title')
    {{__('strings.modelo_index_title')}}
@endsection

@section('content')

<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1>{{__('strings.modelo_index_title')}}</h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="{{ route('modelos.create') }}">{{__('strings.modelo_create_btn')}}&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        @csrf
                        <label for="modeloIdModelo" class="form-label">{{__('strings.idModelo_header')}}</label>
                        <input id="modeloIdModelo" name="modeloIdModelo" class="form-control" value="@isset($modeloIdModelo) {{$modeloIdModelo}} @endisset" placeholder="{{__('strings.search_idModelo_placeholder')}}" />
                        
                        <label for="modeloTipoCarroceria" class="form-label">{{__('strings.tipoCarroceria_header')}}</label>
                        <input id="modeloTipoCarroceria" name="modeloTipoCarroceria" class="form-control" value="@isset($modeloTipoCarroceria) {{$modeloTipoCarroceria}} @endisset" placeholder="{{__('strings.search_tipoCarroceria_placeholder')}}" />

                        <label for="modeloFabricante" class="form-label">{{__('strings.fabricante_header')}}</label>
                        <input id="modeloFabricante" name="modeloFabricante" class="form-control" value="@isset($modeloFabricante) {{$modeloFabricante}} @endisset" placeholder="{{__('strings.search_fabricante_placeholder')}}" />

                        <label for="modeloPotencia" class="form-label">{{__('strings.potencia_header')}}</label>
                        <input id="modeloPotencia" name="modeloPotencia" class="form-control" value="@isset($modeloPotencia) {{$modeloPotencia}} @endisset" placeholder="{{__('strings.search_potencia_placeholder')}}" />

                        <button type="submit" class="btn btn-primary my-2">{{__('strings.search_btn')}}</button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    @if(count($modelos) > 0)
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th>{{__('strings.idModelo_header')}}</th>
                                <th>{{__('strings.tipoCarroceria_header')}}</th>
                                <th>{{__('strings.fabricante_header')}}</th>
                                <th>{{__('strings.potencia_header')}}</th>
                                <th>{{__('strings.actions_header')}}</th>
                            </thead>
                            <tbody>
                            @foreach($modelos as $modelo)
                                <tr>
                                    <td>{{$modelo->idModelo}}</td>
                                    <td>{{$modelo->tipoCarroceria}}</td>
                                    <td>{{$modelo->fabricante}}</td>
                                    <td>{{$modelo->potencia}}</td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Poliza">
                                            <a class="btn btn-success" href="{{ route('modelos.edit', $modelo) }}">{{__('strings.edit_btn')}}</a>&nbsp;&nbsp;
                                            <form name="delete-form-{{$modelo->idModelo}}" action="{{ route('modelos.delete', $modelo) }}" method="post" style="display: inline-block;">
                                                {{ method_field('delete') }}
                                                {{ csrf_field() }}
                                                <button type="submit" class="btn btn-danger">{{__('strings.delete_btn')}}</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="alert alert-warning mt-3">
                            {{__('strings.no_modelos')}}
                        </div>
                    @endif
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                {{ $modelos->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
