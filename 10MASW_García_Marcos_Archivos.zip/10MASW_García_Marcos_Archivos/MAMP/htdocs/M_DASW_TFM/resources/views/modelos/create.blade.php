@extends('layouts.main')

@section('title')
    @isset($modelo)
        {{__('strings.modelo_edit_title')}}
    @else
        {{__('strings.modelo_create_title')}}
    @endisset
@endsection

@section('content')
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    @isset($modelo)
                        <h1>{{__('strings.modelo_edit_title')}} {{$modelo->idModelo}} {{$modelo->tipoCarroceria}} {{$modelo->fabricante}} {{$modelo->potencia}}</h1>
                    @else
                        <h1>{{__('strings.modelo_create_title')}}</h1>
                    @endisset
                </div>
            </div>
            <div class="card-body">
                @isset($modelo)
                    <form name="edit_modelo" action="{{ route('modelos.update', $modelo) }}" method="post">
                    @csrf
                @else
                    <form name="create_modelo" action="{{ route('modelos.store') }}" method="post">
                    @csrf
                @endisset
                    <div class="mb-3">
                        <label for="modeloIdModelo" class="form-label"> {{__('strings.idModelo_header')}}</label>
                        <input id="modeloIdModelo" name="modeloIdModelo" type="text" placeholder="{{__('strings.idModelo_placeholder')}}"
                        class="form-control" required @isset($modelo) value="{{ old('modeloIdModelo', $modelo->idModelo)}}" @else value="{{ old('modeloIdModelo') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="modeloTipoCarroceria" class="form-label"> {{__('strings.tipoCarroceria_header')}}</label>
                        <input id="modeloTipoCarroceria" name="modeloTipoCarroceria" type="text" placeholder="{{__('strings.tipoCarroceria_placeholder')}}"
                        class="form-control" required @isset($modelo) value="{{ old('modeloTipoCarroceria', $modelo->tipoCarroceria)}}" @else value="{{ old('modeloTipoCarroceria') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="modeloFabricante" class="form-label"> {{__('strings.fabricante_header')}}</label>
                        <input id="modeloFabricante" name="modeloFabricante" type="text" placeholder="{{__('strings.fabricante_placeholder')}}"
                        class="form-control" required @isset($modelo) value="{{ old('modeloFabricante', $modelo->fabricante)}}" @else value="{{ old('modeloFabricante') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="modeloPotencia" class="form-label"> {{__('strings.potencia_header')}}</label>
                        <input id="modeloPotencia" name="modeloTipoCarroceria" type="text" placeholder="{{__('strings.potencia_placeholder')}}"
                        class="form-control" required @isset($modelo) value="{{ old('modeloPotencia', $modelo->potencia)}}" @else value="{{ old('modeloPotencia') }}" @endisset />
                    </div>
                    <input type="submit" value="@isset($modelo) {{__('strings.save_btn')}} @else {{__('strings.create_btn')}} @endisset" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
