@extends('layouts.main')

@section('title')
    {{__('strings.lugar_index_title')}}
@endsection

@section('content')

<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1>{{__('strings.lugar_index_title')}}</h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="{{ route('lugars.create') }}">{{__('strings.lugar_create_btn')}}&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        @csrf
                        <label for="lugarResidencia" class="form-label">{{__('strings.residencia_header')}}</label>
                        <input id="lugarResidencia" name="lugarResidencia" class="form-control" value="@isset($lugarResidencia) {{$lugarResidencia}} @endisset" placeholder="{{__('strings.search_residencia_placeholder')}}" />
                        
                        <label for="lugarDistritoPostal" class="form-label">{{__('strings.distritoPostal_header')}}</label>
                        <input id="lugarDistritoPostal" name="lugarDistritoPostal" class="form-control" value="@isset($lugarDistritoPostal) {{$lugarDistritoPostal}} @endisset" placeholder="{{__('strings.search_distritoPostal_placeholder')}}" />

                        <button type="submit" class="btn btn-primary my-2">{{__('strings.search_btn')}}</button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    @if(count($lugars) > 0)
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th>{{__('strings.residencia_header')}}</th>
                                <th>{{__('strings.distritoPostal_header')}}</th>
                                <th>{{__('strings.actions_header')}}</th>
                            </thead>
                            <tbody>
                            @foreach($lugars as $lugar)
                                <tr>
                                    <td>{{$lugar->residencia}}</td>
                                    <td>{{$lugar->distritoPostal}}</td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Lugar">
                                            <a class="btn btn-success" href="{{ route('lugars.edit', $lugar) }}">{{__('strings.edit_btn')}}</a>&nbsp;&nbsp;
                                            <form name="delete-form-{{$lugar->residencia}}" action="{{ route('lugars.delete', $lugar) }}" method="post" style="display: inline-block;">
                                                {{ method_field('delete') }}
                                                {{ csrf_field() }}
                                                <button type="submit" class="btn btn-danger">{{__('strings.delete_btn')}}</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="alert alert-warning mt-3">
                            {{__('strings.no_lugars')}}
                        </div>
                    @endif
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                {{ $lugars->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
