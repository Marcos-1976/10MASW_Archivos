@extends('layouts.main')

@section('title')
    @isset($lugar)
        {{__('strings.lugar_edit_title')}}
    @else
        {{__('strings.lugar_create_title')}}
    @endisset
@endsection

@section('content')
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    @isset($lugar)
                        <h1>{{__('strings.lugar_edit_title')}} {{$lugar->residencia}} {{$lugar->distritoPostal}}</h1>
                    @else
                        <h1>{{__('strings.lugar_create_title')}}</h1>
                    @endisset
                </div>
            </div>
            <div class="card-body">
                @isset($lugar)
                    <form name="edit_lugar" action="{{ route('lugars.update', $lugar) }}" method="post">
                    @csrf
                @else
                    <form name="create_lugar" action="{{ route('lugars.store') }}" method="post">
                    @csrf
                @endisset
                    <div class="mb-3">
                        <label for="lugarResidencia" class="form-label"> {{__('strings.residencia_header')}}</label>
                        <input id="lugarResidencia" name="lugarResidencia" type="text" placeholder="{{__('strings.residencia_placeholder')}}"
                        class="form-control" required @isset($lugar) value="{{ old('lugarResidencia', $lugar->residencia)}}" @else value="{{ old('lugarResidencia') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="lugarDistritoPostal" class="form-label"> {{__('strings.distritoPostal_header')}}</label>
                        <input id="lugarDistritoPostal" name="lugarDistritoPostal" type="text" placeholder="{{__('strings.distritoPostal_placeholder')}}"
                        class="form-control" required @isset($lugar) value="{{ old('lugarDistritoPostal', $lugar->distritoPostal)}}" @else value="{{ old('lugarDistritoPostal') }}" @endisset />
                    </div>
                    <input type="submit" value="@isset($lugar) {{__('strings.save_btn')}} @else {{__('strings.create_btn')}} @endisset" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
