@extends('layouts.main')

@section('title')
    @isset($poliza)
        {{__('strings.poliza_edit_title')}}
    @else
        {{__('strings.poliza_create_title')}}
    @endisset
@endsection

@section('content')
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    @isset($poliza)
                        <h1>{{__('strings.poliza_edit_title')}} {{$poliza->poliza}} {{$poliza->prima}} {{$poliza->fechaAlta}} {{$poliza->fechaVencimiento}} {{$poliza->tipoPoliza}}</h1>
                    @else
                        <h1>{{__('strings.poliza_create_title')}}</h1>
                    @endisset
                </div>
            </div>
            <div class="card-body">
                @isset($poliza)
                    <form name="edit_poliza" action="{{ route('polizas.update', $poliza) }}" method="post">
                    @csrf
                @else
                    <form name="create_poliza" action="{{ route('polizas.store') }}" method="post">
                    @csrf
                @endisset
                    <div class="mb-3">
                        <label for="polizaPrima" class="form-label"> {{__('strings.prima_header')}}</label>
                        <input id="polizaPrima" name="polizaPrima" type="text" placeholder="{{__('strings.prima_placeholder')}}"
                        class="form-control" required @isset($poliza) value="{{ old('polizaPrima', $poliza->prima)}}" @else value="{{ old('polizaPrima') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="polizaPrima" class="form-label"> {{__('strings.prima_header')}}</label>
                        <input id="polizaPrima" name="polizaPrima" type="text" placeholder="{{__('strings.prima_placeholder')}}"
                        class="form-control" required @isset($poliza) value="{{ old('polizaPrima', $poliza->prima)}}" @else value="{{ old('polizaPrima') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="polizaFechaAlta" class="form-label"> {{__('strings.fechaAlta_header')}}</label>
                        <input id="polizaFechaAlta" name="polizaFechaAlta" type="text" placeholder="{{__('strings.fechaAlta_placeholder')}}"
                        class="form-control" required @isset($poliza) value="{{ old('polizaFechaAlta', $poliza->fechaAlta)}}" @else value="{{ old('polizaFechaAlta') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="polizaFechaVencimiento" class="form-label"> {{__('strings.fechaVencimiento_header')}}</label>
                        <input id="polizaFechaVencimiento" name="polizaFechaVencimiento" type="text" placeholder="{{__('strings.fechaVencimiento_placeholder')}}"
                        class="form-control" required @isset($poliza) value="{{ old('polizaFechaVencimiento', $poliza->fechaVencimiento)}}" @else value="{{ old('polizaFechaVencimiento') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="polizaTipo" class="form-label"> {{__('strings.tipoPoliza_header')}}</label>
                        <input id="polizaTipo" name="polizaTipo" type="text" placeholder="{{__('strings.tipoPoliza_placeholder')}}"
                        class="form-control" required @isset($poliza) value="{{ old('polizaTipo', $poliza->tipoPoliza)}}" @else value="{{ old('polizaTipo') }}" @endisset />
                    </div>
                    <input type="submit" value="@isset($poliza) {{__('strings.save_btn')}} @else {{__('strings.create_btn')}} @endisset" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
