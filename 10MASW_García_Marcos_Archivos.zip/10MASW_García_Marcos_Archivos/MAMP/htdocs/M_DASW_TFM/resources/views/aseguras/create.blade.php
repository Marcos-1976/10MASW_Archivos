@extends('layouts.main')

@section('title')
    @isset($asegura)
        {{__('strings.asegura_edit_title')}}
    @else
        {{__('strings.asegura_create_title')}}
    @endisset
@endsection

@section('content')
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    @isset($asegura)
                        <h1>{{__('strings.asegura_edit_title')}} {{$asegura->DNI}} {{$asegura->matricula}}</h1> {{-- Nombre del campo en la BD. --}}
                    @else
                        <h1>{{__('strings.asegura_create_title')}}</h1>
                    @endisset
                </div>
            </div>
            <div class="card-body">
                @isset($asegura)
                    <form name="edit_asegura" action="{{ route('aseguras.update', $asegura) }}" method="post">
                    @csrf
                @else
                    <form name="create_asegura" action="{{ route('aseguras.store') }}" method="post">
                    @csrf
                @endisset
                    <div class="mb-3">
                        <label for="aseguraDNI" class="form-label">{{__('strings.DNI_header')}}</label>
                        <select id="aseguraDNI" name="aseguraDNI" class="form-select">                            
                            @isset($asegura)
                                <option value="-1" selected>{{__('strings.search_DNI_placeholder')}}</option>
                                @foreach($clientes as $cliente)
                                    @if($asegura->DNI == $cliente->DNI)     
                                        <option value="{{$cliente->DNI}}" selected>{{$cliente->DNI}}</option>
                                    @else
                                        <option value="{{$cliente->DNI}}">{{$cliente->DNI}}</option>
                                    @endif
                                @endforeach
                            @else
                                <option value="-1" selected>{{__('strings.DNI_placeholder')}}</option>
                                @foreach($clientes as $cliente)
                                    <option value="{{$cliente->DNI}}">{{$cliente->DNI}}</option>
                                @endforeach
                            @endisset
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="aseguraMatricula" class="form-label">{{__('strings.matricula_header')}}</label>
                        <select id="aseguraMatricula" name="aseguraMatricula" class="form-select">                            
                            @isset($asegura)
                                <option value="-1" selected>{{__('strings.search_matricula_placeholder')}}</option>
                                @foreach($vehiculos as $vehiculo)
                                    @if($asegura->matricula == $vehiculo->matricula)     
                                        <option value="{{$vehiculo->matricula}}" selected>{{$vehiculo->matricula}}</option>
                                    @else
                                        <option value="{{$vehiculo->matricula}}">{{$vehiculo->matricula}}</option>
                                    @endif
                                @endforeach
                            @else
                                <option value="-1" selected>{{__('strings.matricula_placeholder')}}</option>
                                @foreach($vehiculos as $vehiculo)
                                    <option value="{{$vehiculo->matricula}}">{{$vehiculo->matricula}}</option>
                                @endforeach
                            @endisset
                        </select>
                    </div>
                    <input type="submit" value="@isset($asegura) {{__('strings.save_btn')}} @else {{__('strings.create_btn')}} @endisset" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
