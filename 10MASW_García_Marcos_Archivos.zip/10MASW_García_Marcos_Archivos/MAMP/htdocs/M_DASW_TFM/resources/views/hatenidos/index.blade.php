@extends('layouts.main')

@section('title')
    {{__('strings.hatenido_index_title')}}
@endsection

@section('content')
{{--
<h1>{{__('strings.hatenido_index_title')}}</h1>
--}}

<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1>{{__('strings.hatenido_index_title')}}</h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="{{ route('hatenidos.create') }}">{{__('strings.hatenido_create_btn')}}&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        @csrf
                        <label for="hatenidoMatricula" class="form-label">{{__('strings.matricula_header')}}</label>
                        <select id="hatenidoMatricula" name="hatenidoMatricula" class="form-select">
                            <option value="-1" selected>{{__('strings.search_matricula_placeholder')}}</option>
                            @foreach($vehiculos as $vehiculo)
                                @if($hatenidoMatricula == $vehiculo->matricula) {{-- Nombre del campo en la BD. --}}
                                    <option value="{{$vehiculo->matricula}}" selected>{{$vehiculo->matricula}}</option>
                                @else
                                    <option value="{{$vehiculo->matricula}}">{{$vehiculo->matricula}}</option>
                                @endif
                            @endforeach
                        </select>
                        
                        <label for="hatenidoIdAccidente" class="form-label">{{__('strings.idAccidente_header')}}</label>
                        <select id="hatenidoIdAccidente" name="hatenidoIdAccidente" class="form-select">
                            <option value="-1" selected>{{__('strings.search_idAccidente_placeholder')}}</option>
                            @foreach($accidentes as $accidente)
                                @if($hatenidoIdAccidente == $accidente->idAccidente)
                                    <option value="{{$accidente->idAccidente}}" selected>{{$accidente->idAccidente}}</option>
                                @else
                                    <option value="{{$accidente->idAccidente}}">{{$accidente->idAccidente}}</option>
                                @endif
                            @endforeach
                        </select>
                        
                        <button type="submit" class="btn btn-primary my-2">{{__('strings.search_btn')}}</button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    @if(count($hatenidos) > 0)
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th>{{__('strings.matricula_header')}}</th>
                                <th>{{__('strings.idAccidente_header')}}</th>
                                <th>{{__('strings.actions_header')}}</th>
                            </thead>
                            <tbody>
                            @foreach($hatenidos as $hatenido)
                                <tr>
                                    <td>{{$hatenido->vehiculo->matricula}}</td> {{-- Nombre del campo en la BD. --}}
                                    <td>{{$hatenido->accidente->idAccidente}}</td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Hatenido">
                                            <a class="btn btn-success" href="{{ route('hatenidos.edit', $hatenido) }}">{{__('strings.edit_btn')}}</a>&nbsp;&nbsp;
                                            <form name="delete-form-{{$hatenido->matricula}}" action="{{ route('hatenidos.delete', $hatenido) }}" method="post" style="display: inline-block;"> {{-- Nombre de la clave primaria en la BD. --}}
                                                {{ method_field('delete') }}
                                                {{ csrf_field() }}
                                                <button type="submit" class="btn btn-danger">{{__('strings.delete_btn')}}</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="alert alert-warning mt-3">
                            {{__('strings.no_hatenidos')}}
                        </div>
                    @endif
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                {{ $hatenidos->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
