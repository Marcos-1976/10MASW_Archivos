@extends('layouts.main')

@section('title')
    @isset($hatenido)
        {{__('strings.hatenido_edit_title')}}
    @else
        {{__('strings.hatenido_create_title')}}
    @endisset
@endsection

@section('content')
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    @isset($hatenido)
                        <h1>{{__('strings.hatenido_edit_title')}} {{$hatenido->matricula}} {{$hatenido->idAccidente}}</h1> {{-- Nombre del campo en la BD. --}}
                    @else
                        <h1>{{__('strings.hatenido_create_title')}}</h1>
                    @endisset
                </div>
            </div>
            <div class="card-body">
                @isset($hatenido)
                    <form name="edit_hatenido" action="{{ route('hatenidos.update', $hatenido) }}" method="post">
                    @csrf
                @else
                    <form name="create_hatenido" action="{{ route('hatenidos.store') }}" method="post">
                    @csrf
                @endisset
                    <div class="mb-3">
                        <label for="hatenidoMatricula" class="form-label">{{__('strings.matricula_header')}}</label>
                        <select id="hatenidoMatricula" name="hatenidoMatricula" class="form-select">                            
                            @isset($hatenido)
                                <option value="-1" selected>{{__('strings.search_matricula_placeholder')}}</option>
                                @foreach($vehiculos as $vehiculo)
                                    @if($hatenido->matricula == $vehiculo->matricula)     
                                        <option value="{{$vehiculo->matricula}}" selected>{{$vehiculo->matricula}}</option>
                                    @else
                                        <option value="{{$vehiculo->matricula}}">{{$vehiculo->matricula}}</option>
                                    @endif
                                @endforeach
                            @else
                                <option value="-1" selected>{{__('strings.matricula_placeholder')}}</option>
                                @foreach($vehiculos as $vehiculo)
                                    <option value="{{$vehiculo->matricula}}">{{$vehiculo->matricula}}</option>
                                @endforeach
                            @endisset
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="hatenidoIdAccidente" class="form-label">{{__('strings.idAccidente_header')}}</label>
                        <select id="hatenidoIdAccidente" name="hatenidoIdAccidente" class="form-select">                            
                            @isset($hatenido)
                                <option value="-1" selected>{{__('strings.search_idAccidente_placeholder')}}</option>
                                @foreach($accidentes as $accidente)
                                    @if($hatenido->idAccidente == $accidente->idAccidente)     
                                        <option value="{{$accidente->idAccidente}}" selected>{{$accidente->idAccidente}}</option>
                                    @else
                                        <option value="{{$accidente->idAccidente}}">{{$accidente->idAccidente}}</option>
                                    @endif
                                @endforeach
                            @else
                                <option value="-1" selected>{{__('strings.idAccidente_placeholder')}}</option>
                                @foreach($accidentes as $accidente)
                                    <option value="{{$accidente->idAccidente}}">{{$accidente->idAccidente}}</option>
                                @endforeach
                            @endisset
                        </select>
                    </div>
                    <input type="submit" value="@isset($hatenido) {{__('strings.save_btn')}} @else {{__('strings.create_btn')}} @endisset" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
