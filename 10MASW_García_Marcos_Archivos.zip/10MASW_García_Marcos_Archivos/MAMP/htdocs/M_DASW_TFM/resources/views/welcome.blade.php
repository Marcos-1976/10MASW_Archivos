@extends('layouts.main')
    <!-- Uso de herramientas Frontend CSS -->
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/reloj.css">

@section('title')
    {{__('strings.home_title')}}
@endsection

@section('content')
<body onload="startTime()">

<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <marquee bgcolor="#FF7070"> Máster en Desarrollo de Aplicaciones y Servicios Web - Trabajo Fin de Máster </marquee>
            <div class="card-header border-0">
                <a title="logoVIU" href="https://www.universidadviu.com/es/master-desarrollo-web">
                    <img class="logoVIU" src="imagenes/logoVIU.png" alt="logoVIU">
                </a>
                <div class="row">              
                    <h1>{{__('strings.home_title')}}</h1>
                    <h2 class="neon">FORCANO</h2>
                </div>
            </div>
            <div class="card-body">
                <div class="col-12">
                    <div class="d-flex align-items-center justify-content-center">
                        <div class="col-2 mx-2">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Ventas de Pólizas</h5>
                                    <p class="card-text">Listado y gestión de la venta de pólizas.</p>
                                    <a class="btn btn-primary" href="{{route('compras.index')}}">Listado de ventas</a>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Pólizas</h5>
                                    <p class="card-text">Listado y gestión de las pólizas.</p>
                                    <a class="btn btn-primary" href="{{route('polizas.index')}}">Listado de pólizas</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-2 mx-2">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Clientes</h5>
                                    <p class="card-text">Listado y gestión de los clientes.</p>
                                    <a class="btn btn-primary" href="{{route('clientes.index')}}">Listado de clientes</a>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Lugares</h5>
                                    <p class="card-text">Listado y gestión de la residencia de los clientes.</p>
                                    <a class="btn btn-primary" href="{{route('lugars.index')}}">Listado de lugares</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-2 mx-2">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Propietarios</h5>
                                    <p class="card-text">Listado y gestión de los propietarios de vehículos.</p>
                                    <a class="btn btn-primary" href="{{route('aseguras.index')}}">Listado de propietarios</a>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Vehículos</h5>
                                    <p class="card-text">Listado y gestión de los vehículos.</p>
                                    <a class="btn btn-primary" href="{{route('vehiculos.index')}}">Listado de vehículos</a>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Modelos</h5>
                                    <p class="card-text">Listado y gestión de modelos de vehículos.</p>
                                    <a class="btn btn-primary" href="{{route('modelos.index')}}">Listado de modelos</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-2 mx-2">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Vehículos accidentados</h5>
                                    <p class="card-text">Listado y gestión de los vehículos accidentados.</p>
                                    <a class="btn btn-primary" href="{{route('hatenidos.index')}}">Listado de vehículos accidentados</a>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Especificación de accidentes</h5>
                                    <p class="card-text">Listado y gestión de especificación de los accidentes.</p>
                                    <a class="btn btn-primary" href="{{route('accidentes.index')}}">Listado de accidentes</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clockdate-wrapper"> <!-- Reloj con fecha -->
            <div id="clock"></div>
            <div id="date"></div>
        </div>
    </div>
</div>

<footer>
	<hr> <!-- Línea horizontal -->
	<details>
		<summary>Información:</summary>
        <div class="video"> <!-- Vídeo -->
            <iframe width="560" height="315" src="https://www.youtube.com/embed/4PUwQCAyM4Y" title="¿Qué es y cómo funciona un seguro de auto?" frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
    </details>
    <br>
    <details class="creditos">
		<summary>Créditos:</summary>
		<p align="center">
            <tt>Desarrollado por </tt><a href="mailto:ma.forcano@gmail.com?subject=Hola&body=Solicito más información."><em>Marcos García Forcano</em></a><br>
			<tt>Copyleft 2023</tt><br>
		</p>
        <div class="audio"> <!-- Audio> -->
            <audio id="autoaudio"></audio>
        </div>
    </details>
</footer>

<!-- Uso de herramientas Frontend JavaScript -->
<script type="text/javascript" src="js/eventos.js"></script>
<script type="text/javascript" src="js/reloj.js"></script>

@endsection
