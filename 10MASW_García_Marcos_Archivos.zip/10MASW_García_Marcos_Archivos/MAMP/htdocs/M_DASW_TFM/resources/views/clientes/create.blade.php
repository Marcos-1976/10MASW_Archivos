@extends('layouts.main')

@section('title')
    @isset($cliente)
        {{__('strings.cliente_edit_title')}}
    @else
        {{__('strings.cliente_create_title')}}
    @endisset
@endsection

@section('content')
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    @isset($cliente)
                        <h1>{{__('strings.cliente_edit_title')}} {{$cliente->DNI}} {{$cliente->nombre}} {{$cliente->telefonoCliente}} {{$cliente->eMail}} {{$cliente->fechaNacimiento}} {{$cliente->residencia}}</h1> {{-- Nombre del campo en la BD. --}}
                    @else
                        <h1>{{__('strings.cliente_create_title')}}</h1>
                    @endisset
                </div>
            </div>
            <div class="card-body">
                @isset($cliente)
                    <form name="edit_cliente" action="{{ route('clientes.update', $cliente) }}" method="post">
                    @csrf
                @else
                    <form name="create_cliente" action="{{ route('clientes.store') }}" method="post">
                    @csrf
                @endisset
                    <div class="mb-3">
                        <label for="clienteDNI" class="form-label"> {{__('strings.DNI_header')}}</label>
                        <input id="clienteDNI" name="clienteDNI" type="text" placeholder="{{__('strings.DNI_placeholder')}}"
                        class="form-control" required @isset($cliente) value="{{ old('clienteDNI', $cliente->DNI)}}" @else value="{{ old('clienteDNI') }}" @endisset /> {{-- Nombre del campo en la BD. --}}
                    </div>
                    <div class="mb-3">
                        <label for="clienteNombre" class="form-label"> {{__('strings.nombre_header')}}</label>
                        <input id="clienteNombre" name="clienteNombre" type="text" placeholder="{{__('strings.nombre_placeholder')}}"
                        class="form-control" required @isset($cliente) value="{{ old('clienteNombre', $cliente->nombre)}}" @else value="{{ old('clienteNombre') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="clienteTelefono" class="form-label"> {{__('strings.telefono_header')}}</label>
                        <input id="clienteTelefono" name="clienteTelefono" type="text" placeholder="{{__('strings.telefono_placeholder')}}"
                        class="form-control" required @isset($cliente) value="{{ old('clienteTelefono', $cliente->telefonoCliente)}}" @else value="{{ old('clienteTelefono') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="clienteEmail" class="form-label"> {{__('strings.email_header')}}</label>
                        <input id="clienteEmail" name="clienteEmail" type="text" placeholder="{{__('strings.email_placeholder')}}"
                        class="form-control" required @isset($cliente) value="{{ old('clienteEmail', $cliente->eMail)}}" @else value="{{ old('clienteEmail') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="clienteFechaNacimiento" class="form-label"> {{__('strings.fechaNacimiento_header')}}</label>
                        <input id="clienteFechaNacimiento" name="clienteFechaNacimiento" type="text" placeholder="{{__('strings.fechaNacimiento_placeholder')}}"
                        class="form-control" required @isset($cliente) value="{{ old('clientefechaNacimiento', $cliente->fechaNacimiento)}}" @else value="{{ old('clienteFechaNacimiento') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="clienteResidencia" class="form-label">{{__('strings.residencia_header')}}</label>
                        <select id="clienteResidencia" name="clienteResidencia" class="form-select">                            
                            @isset($cliente)
                                <option value="-1" selected>{{__('strings.search_residencia_placeholder')}}</option>
                                @foreach($lugars as $lugar)
                                    @if($cliente->residencia == $lugar->residencia)     
                                        <option value="{{$lugar->residencia}}" selected>{{$lugar->residencia}}</option>
                                    @else
                                        <option value="{{$lugar->residencia}}">{{$lugar->residencia}}</option>
                                    @endif
                                @endforeach
                            @else
                                <option value="-1" selected>{{__('strings.residencia_placeholder')}}</option>
                                @foreach($lugars as $lugar)
                                    <option value="{{$lugar->residencia}}">{{$lugar->residencia}}</option>
                                @endforeach
                            @endisset
                        </select>
                    </div>
                    <input type="submit" value="@isset($cliente) {{__('strings.save_btn')}} @else {{__('strings.create_btn')}} @endisset" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
