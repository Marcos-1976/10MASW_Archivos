@extends('layouts.main')

@section('title')
    {{__('strings.cliente_index_title')}}
@endsection

@section('content')
{{--
<h1>{{__('strings.cliente_index_title')}}</h1>
--}}

<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1>{{__('strings.cliente_index_title')}}</h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="{{ route('clientes.create') }}">{{__('strings.cliente_create_btn')}}&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        @csrf
                        <label for="clienteDNI" class="form-label">{{__('strings.DNI_header')}}</label>
                        <input id="clienteDNI" name="clienteDNI" class="form-control" value="@isset($clienteDNI) {{$clienteDNI}} @endisset" placeholder="{{__('strings.search_DNI_placeholder')}}" />
                        
                        <label for="clienteNombre" class="form-label">{{__('strings.nombre_header')}}</label>
                        <input id="clienteNombre" name="clienteNombre" class="form-control" value="@isset($clienteNombre) {{$clienteNombre}} @endisset" placeholder="{{__('strings.search_nombre_placeholder')}}" />

                        <label for="clienteTelefono" class="form-label">{{__('strings.telefono_header')}}</label>
                        <input id="clienteTelefono" name="clienteTelefono" class="form-control" value="@isset($clienteTelefono) {{$clienteTelefono}} @endisset" placeholder="{{__('strings.search_telefono_placeholder')}}" />

                        <label for="clienteEmail" class="form-label">{{__('strings.email_header')}}</label>
                        <input id="clienteEmail" name="clienteEmail" class="form-control" value="@isset($clienteEmail) {{$clienteEmail}} @endisset" placeholder="{{__('strings.search_email_placeholder')}}" />

                        <label for="clienteFechaNacimiento" class="form-label">{{__('strings.fechaNacimiento_header')}}</label>
                        <input id="clienteFechaNacimiento" name="clienteFechaNacimiento" class="form-control" value="@isset($clienteFechaNacimiento) {{$clienteFechaNacimiento}} @endisset" placeholder="{{__('strings.search_fechaNacimiento_placeholder')}}" />
                        
                        <label for="clienteResidencia" class="form-label">{{__('strings.residencia_header')}}</label>
                        <select id="clienteResidencia" name="clienteResidencia" class="form-select">
                            <option value="-1" selected>{{__('strings.search_residencia_placeholder')}}</option>
                            @foreach($lugars as $lugar)
                                @if($clienteResidencia == $lugar->residencia) {{-- Nombre del campo en la BD. --}}
                                    <option value="{{$lugar->residencia}}" selected>{{$lugar->residencia}}</option>
                                @else
                                    <option value="{{$lugar->residencia}}">{{$lugar->residencia}}</option>
                                @endif
                            @endforeach
                        </select>
                        
                        <button type="submit" class="btn btn-primary my-2">{{__('strings.search_btn')}}</button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    @if(count($clientes) > 0)
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th>{{__('strings.DNI_header')}}</th>
                                <th>{{__('strings.nombre_header')}}</th>
                                <th>{{__('strings.telefono_header')}}</th>
                                <th>{{__('strings.email_header')}}</th>
                                <th>{{__('strings.fechaNacimiento_header')}}</th>
                                <th>{{__('strings.residencia_header')}}</th>
                                <th>{{__('strings.actions_header')}}</th>
                            </thead>
                            <tbody>
                            @foreach($clientes as $cliente)
                                <tr>
                                    <td>{{$cliente->DNI}}</td> {{-- Nombre del campo en la BD. --}}
                                    <td>{{$cliente->nombre}}</td>
                                    <td>{{$cliente->telefonoCliente}}</td>
                                    <td>{{$cliente->eMail}}</td>
                                    <td>{{$cliente->fechaNacimiento}}</td>
                                    <td>{{$cliente->lugar->residencia.' - Distrito postal: '.$cliente->lugar->distritoPostal}}</td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Cliente">
                                            <a class="btn btn-success" href="{{ route('clientes.edit', $cliente) }}">{{__('strings.edit_btn')}}</a>&nbsp;&nbsp;
                                            <form name="delete-form-{{$cliente->DNI}}" action="{{ route('clientes.delete', $cliente) }}" method="post" style="display: inline-block;"> {{-- Nombre de la clave primaria en la BD. --}}
                                                {{ method_field('delete') }}
                                                {{ csrf_field() }}
                                                <button type="submit" class="btn btn-danger">{{__('strings.delete_btn')}}</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="alert alert-warning mt-3">
                            {{__('strings.no_clientes')}}
                        </div>
                    @endif
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                {{ $clientes->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
