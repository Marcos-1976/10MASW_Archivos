@extends('layouts.main')

@section('title')
    @isset($accidente)
        {{__('strings.accidente_edit_title')}}
    @else
        {{__('strings.accidente_create_title')}}
    @endisset
@endsection

@section('content')
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    @isset($accidente)
                        <h1>{{__('strings.accidente_edit_title')}} {{$accidente->accidente}} {{$accidente->fechaAccidente}} {{$accidente->lugarAccidente}} {{$accidente->porcentajeDanio}} {{$accidente->coberturaSiniestro}}</h1>
                    @else
                        <h1>{{__('strings.accidente_create_title')}}</h1>
                    @endisset
                </div>
            </div>
            <div class="card-body">
                @isset($accidente)
                    <form name="edit_accidente" action="{{ route('accidentes.update', $accidente) }}" method="post">
                    @csrf
                @else
                    <form name="create_accidente" action="{{ route('accidentes.store') }}" method="post">
                    @csrf
                @endisset
                    <div class="mb-3">
                        <label for="accidenteFechaccidente" class="form-label"> {{__('strings.fechaAccidente_header')}}</label>
                        <input id="accidenteFechaAccidente" name="accidenteFechaAccidente" type="text" placeholder="{{__('strings.fechaAccidente_placeholder')}}"
                        class="form-control" required @isset($accidente) value="{{ old('accidenteFechaAccidente', $accidente->fechaAccidente)}}" @else value="{{ old('accidenteFechaAccidente') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="accidenteLugarAccidente" class="form-label"> {{__('strings.lugarAccidente_header')}}</label>
                        <input id="accidenteLugarAccidente" name="accidenteLugarAccidente" type="text" placeholder="{{__('strings.lugarAccidente_placeholder')}}"
                        class="form-control" required @isset($accidente) value="{{ old('accidenteLugarAccidente', $accidente->lugarAccidente)}}" @else value="{{ old('accidenteLugarAccidente') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="accidentePorcentajeDanio" class="form-label"> {{__('strings.porcentajeDanio_header')}}</label>
                        <input id="accidentePorcentajeDanio" name="accidentePorcentajeDanio" type="text" placeholder="{{__('strings.porcentajeDanio_placeholder')}}"
                        class="form-control" required @isset($accidente) value="{{ old('accidentePorcentajeDanio', $accidente->porcentajeDanio)}}" @else value="{{ old('accidentePorcentajeDanio') }}" @endisset />
                    </div>
                    <div class="mb-3">
                        <label for="accidenteCoberturaSiniestro" class="form-label"> {{__('strings.coberturaSiniestro_header')}}</label>
                        <input id="accidenteCoberturaSiniestro" name="accidenteCoberturaSiniestro" type="text" placeholder="{{__('strings.coberturaSiniestro_placeholder')}}"
                        class="form-control" required @isset($accidente) value="{{ old('accidenteCoberturaSiniestro', $accidente->coberturaSiniestro)}}" @else value="{{ old('accidenteCoberturaSiniestro') }}" @endisset />
                    </div>
                    <input type="submit" value="@isset($accidente) {{__('strings.save_btn')}} @else {{__('strings.create_btn')}} @endisset" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
