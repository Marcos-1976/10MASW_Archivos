@extends('layouts.main')

@section('title')
    {{__('strings.accidente_index_title')}}
@endsection

@section('content')

<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1>{{__('strings.accidente_index_title')}}</h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="{{ route('accidentes.create') }}">{{__('strings.accidente_create_btn')}}&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        @csrf
                        <label for="accidenteIdAccidente" class="form-label">{{__('strings.idAccidente_header')}}</label>
                        <input id="accidenteIdAccidente" name="accidenteIdAccidente" class="form-control" value="@isset($accidenteIdAccidente) {{$accidenteIdAccidente}} @endisset" placeholder="{{__('strings.search_idAccidente_placeholder')}}" />
                        
                        <label for="accidenteFechaAccidente" class="form-label">{{__('strings.fechaAccidente_header')}}</label>
                        <input id="accidenteFechaAccidente" name="accidenteFechaAccidente" class="form-control" value="@isset($accidenteFechaAccidente) {{$accidenteFechaAccidente}} @endisset" placeholder="{{__('strings.search_fechaAccidente_placeholder')}}" />

                        <label for="accidenteLugarAccidente" class="form-label">{{__('strings.lugarAccidente_header')}}</label>
                        <input id="accidenteLugarAccidente" name="accidenteLugarAccidente" class="form-control" value="@isset($accidenteLugarAccidente) {{$accidenteLugarAccidente}} @endisset" placeholder="{{__('strings.search_lugarAccidente_placeholder')}}" />

                        <label for="accidentePorcentajeDanio" class="form-label">{{__('strings.porcentajeDanio_header')}}</label>
                        <input id="accidentePorcentajeDanio" name="accidentePorcentajeDanio" class="form-control" value="@isset($accidentePorcentajeDanio) {{$accidentePorcentajeDanio}} @endisset" placeholder="{{__('strings.search_porcentajeDanio_placeholder')}}" />
                        
                        <label for="accidenteCoberturaSiniestro" class="form-label">{{__('strings.coberturaSiniestro_header')}}</label>
                        <input id="accidenteCoberturaSiniestro" name="accidenteCoberturaSiniestro" class="form-control" value="@isset($accidenteCoberturaSiniestro) {{$accidenteCoberturaSiniestro}} @endisset" placeholder="{{__('strings.search_coberturaSiniestro_placeholder')}}" />

                        <button type="submit" class="btn btn-primary my-2">{{__('strings.search_btn')}}</button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    @if(count($accidentes) > 0)
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th>{{__('strings.idAccidente_header')}}</th>
                                <th>{{__('strings.fechaAccidente_header')}}</th>
                                <th>{{__('strings.lugarAccidente_header')}}</th>
                                <th>{{__('strings.porcentajeDanio_header')}}</th>
                                <th>{{__('strings.coberturaSiniestro_header')}}</th>
                                <th>{{__('strings.actions_header')}}</th>
                            </thead>
                            <tbody>
                            @foreach($accidentes as $accidente)
                                <tr>
                                    <td>{{$accidente->idAccidente}}</td>
                                    <td>{{$accidente->fechaAccidente}}</td>
                                    <td>{{$accidente->lugarAccidente}}</td>
                                    <td>{{$accidente->porcentajeDanio}}</td>
                                    <td>{{$accidente->coberturaSiniestro}}</td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Accidente">
                                            <a class="btn btn-success" href="{{ route('accidentes.edit', $accidente) }}">{{__('strings.edit_btn')}}</a>&nbsp;&nbsp;
                                            <form name="delete-form-{{$accidente->idAccidente}}" action="{{ route('accidentes.delete', $accidente) }}" method="post" style="display: inline-block;">
                                                {{ method_field('delete') }}
                                                {{ csrf_field() }}
                                                <button type="submit" class="btn btn-danger">{{__('strings.delete_btn')}}</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="alert alert-warning mt-3">
                            {{__('strings.no_accidentes')}}
                        </div>
                    @endif
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                {{ $accidentes->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
