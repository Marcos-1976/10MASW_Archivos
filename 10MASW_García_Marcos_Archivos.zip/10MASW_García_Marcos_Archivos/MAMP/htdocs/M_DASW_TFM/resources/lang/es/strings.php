<?php
return [
    // General
    'home_title' => 'Correduría de Seguros de automóviles',

    'create_btn' => 'Crear',
    'save_btn' => 'Guardar',
    'edit_btn' => 'Editar',
    'delete_btn' => 'Borrar',
    'search_btn' => 'Buscar',

    'actions_header' => 'Acciones',

    // Clientes
    'cliente_create_btn' => 'Crear cliente',

    'cliente_index_title' => 'Listado de clientes',
    'cliente_edit_title' => 'Editar cliente',
    'cliente_create_title' => 'Crear cliente',

    'DNI_header' => 'D.N.I.',
    'nombre_header' => 'Nombre y apellidos',
    'telefono_header' => 'Teléfono',
    'email_header' => 'Correo electrónico',
    'IBAN_header' => 'Cuenta bancaria',
    'fechaNacimiento_header' => 'Fecha de nacimiento',
    'residencia_header' => 'Residencia',

    'DNI_placeholder' => 'Introduce el D.N.I.',
    'nombre_placeholder' => 'Introduce el nombre y los apellidos',
    'telefono_placeholder' => 'Introduce el teléfono',
    'email_placeholder' => 'Introduce el correo electrónico',
    'IBAN_placeholder' => 'Introduce el número de cuenta bancaria',
    'fechaNacimiento_placeholder' => 'Introduce la fecha de nacimiento',
    'residencia_placeholder' => 'Introduce la residencia',

    'search_DNI_placeholder' => 'D.N.I. del cliente a buscar...',
    'search_nombre_placeholder' => 'Nombre y apellidos del cliente a buscar...',
    'search_telefono_placeholder' => 'Teléfono del cliente a buscar...',
    'search_email_placeholder' => 'Correo electrónico del cliente a buscar...',
    'search_IBAN_placeholder' => 'Cuenta bancaria del cliente a buscar...',
    'search_fechaNacimiento_placeholder' => 'Fecha de nacimiento del cliente a buscar...',
    'search_residencia_placeholder' => 'Residencia del cliente a buscar...',

    'no_clientes' => 'No existen clientes',

    // Lugares
    'lugar_create_btn' => 'Crear lugar',

    'lugar_index_title' => 'Listado de lugares',
    'lugar_edit_title' => 'Editar lugar',
    'lugar_create_title' => 'Crear lugar',

    'residencia_header' => 'Residencia',
    'distritoPostal_header' => 'Distrito Postal',

    'residencia_placeholder' => 'Introduce la residencia',
    'distritoPostal_placeholder' => 'Introduce el distrito postal',

    'search_residencia_placeholder' => 'Residencia del cliente a buscar...',
    'search_distritoPostal_placeholder' => 'Distrito postal del cliente a buscar...',

    'no_lugars' => 'No existen lugares',

    // Compras
    'compra_create_btn' => 'Crear compra de cliente',

    'compra_index_title' => 'Listado de compras de clientes',
    'compra_edit_title' => 'Editar compra de cliente',
    'compra_create_title' => 'Crear compra de cliente',
    /*
    'DNI_header' => 'D.N.I.',
    'idPoliza_header' => 'Número de póliza',

    'DNI_placeholder' => 'Introduce el D.N.I.',
    'idPoliza_placeholder' => 'Introduce el número de póliza',
   
    'search_DNI_placeholder' => 'D.N.I. del cliente a buscar...',   
    'search_idPoliza_placeholder' => 'Número de póliza a buscar...',
    */
    'no_compras' => 'No existen compras de clientes',

    // Pólizas
    'poliza_create_btn' => 'Crear póliza',

    'poliza_index_title' => 'Listado de pólizas',
    'poliza_edit_title' => 'Editar póliza',
    'poliza_create_title' => 'Crear póliza',

    'idPoliza_header' => 'Número de póliza',
    'prima_header' => 'Cantidad de la prima (€)',
    'fechaAlta_header' => 'Fecha de alta de la póliza',
    'fechaVencimiento_header' => 'Fecha de vencimiento de la póliza',
    'tipoPoliza_header' => 'Tipo de póliza',

    'idPoliza_placeholder' => 'Introduce el número de póliza',
    'prima_placeholder' => 'Introduce el precio de la prima',
    'fechaAlta_placeholder' => 'Introduce la fecha de alta de la póliza',
    'fechaVencimiento_placeholder' => 'Introduce la fecha de vencimiento de la póliza',
    'tipoPoliza_placeholder' => 'Introduce el tipo de póliza',

    'search_idPoliza_placeholder' => 'Número de póliza a buscar...',
    'search_prima_placeholder' => 'Precio de la prima a buscar...',
    'search_fechaAlta_placeholder' => 'Fecha de alta de la póliza a buscar...',
    'search_fechaVencimiento_placeholder' => 'Fecha de vencimiento de la póliza a buscar...',
    'search_tipoPoliza_placeholder' => 'Tipo de póliza a buscar...',

    'no_polizas' => 'No existen pólizas',

    // Propietarios de vehículos
    'asegura_create_btn' => 'Crear propietario de vehículo',

    'asegura_index_title' => 'Listado de propietarios de vehículos',
    'asegura_edit_title' => 'Editar propietario de vehículo',
    'asegura_create_title' => 'Crear propietario de vehículo',
    /*
    'DNI_header' => 'D.N.I.',
    'matricula_header' => 'Matrícula del vehículo',

    'DNI_placeholder' => 'Introduce el D.N.I.',
    'matricula_placeholder' => 'Introduce la matrícula del vehículo',
   
    'search_DNI_placeholder' => 'D.N.I. del cliente a buscar...',   
    'search_matricula_placeholder' => 'Matrícula del vehículo a buscar...',
    */
    'no_aseguras' => 'No existen propietarios de vehiculos',

    // Vehículos
    'vehiculo_create_btn' => 'Crear vehículo',

    'vehiculo_index_title' => 'Listado de vehículos',
    'vehiculo_edit_title' => 'Editar vehículo',
    'vehiculo_create_title' => 'Crear vehículo',

    'matricula_header' => 'Matrícula del vehículo',
    'fechaMatricula_header' => 'Fecha de matriculación del vehículo',
    'color_header' => 'Color del vehículo',
    'precio_header' => 'Precio del vehículo (€)',
    'kilometraje_header' => 'Kilómetros del vehículo',
    'antecedentes_header' => 'Antecedentes del vehículo',
    //'idModelo_header' => 'Modelo de vehículo',   

    'matricula_placeholder' => 'Introduce la matrícula del vehículo',
    'fechaMatricula_placeholder' => 'Introduce la fecha de matriculación del vehículo',
    'color_placeholder' => 'Introduce el color del vehículo',
    'precio_placeholder' => 'Introduce el precio del vehículo',
    'kilometraje_placeholder' => 'Introduce el kilometraje del vehículo',
    'antecedentes_placeholder' => 'Introduce los antecedentes del vehículo',
    //'idModelo_placeholder' => 'Introduce el modelo de vehículo',

    'search_matricula_placeholder' => 'Matrícula del vehículo a buscar...',
    'search_fechaMatricula_placeholder' => 'Fecha de matriculación del vehículo a buscar...',
    'search_color_placeholder' => 'Color del vehículo a buscar...',
    'search_precio_placeholder' => 'Precio del vehículo a buscar...',
    'search_kilometraje_placeholder' => 'Kilometraje del vehículo a buscar...',
    'search_antecedentes_placeholder' => 'Antecedentes del vehículo a buscar...',
    //'search_idModelo_placeholder' => 'Modelo de vehículo a buscar...',

    'no_vehiculos' => 'No existen vehículos',

    // Modelos
    'modelo_create_btn' => 'Crear modelo',

    'modelo_index_title' => 'Listado de modelos',
    'modelo_edit_title' => 'Editar modelo',
    'modelo_create_title' => 'Crear modelo',

    'idModelo_header' => 'Modelo de vehículo',
    'tipoCarroceria_header' => 'Carrocería del modelo',
    'fabricante_header' => 'Fabricante del modelo',
    'potencia_header' => 'Potencia del modelo (CV)',

    'idModelo_placeholder' => 'Introduce el modelo de vehículo',
    'tipoCarroceria_placeholder' => 'Introduce el tipo de carrocería del modelo',
    'fabricante_placeholder' => 'Introduce el fabricante del modelo',
    'potencia_placeholder' => 'Introduce la potencia del modelo',

    'search_idModelo_placeholder' => 'Modelo de vehículo a buscar...',
    'search_tipoCarroceria_placeholder' => 'Tipo de carrocería del modelo a buscar...',
    'search_fabricante_placeholder' => 'Fabricante del modelo a buscar...',
    'search_potencia_placeholder' => 'Potencia del modelo a buscar...',

    'no_modelos' => 'No existen modelos',

    // Vehículos accidentados
    'hatenido_create_btn' => 'Crear vehículo accidentado',

    'hatenido_index_title' => 'Listado de vehículos accidentados',
    'hatenido_edit_title' => 'Editar vehículo accidentado',
    'hatenido_create_title' => 'Crear vehículo accidentado',
    /*
    'matricula_header' => 'Matrícula del vehículo',
    'idAccidente_header' => 'Número de accidente',

    'matricula_placeholder' => 'Introduce la matrícula del vehículo',
    'idAccidente_placeholder' => 'Introduce el número de accidente',
   
    'search_matricula_placeholder' => 'Matrícula del vehículo a buscar...',
    'search_idAccidente_placeholder' => 'Número de accidente a buscar...',
    */
    'no_hatenidos' => 'No existen vehículos accidentados',

    // Especificación de accidentes
    'accidente_create_btn' => 'Crear especificación de accidente',

    'accidente_index_title' => 'Listado de especificaciones de accidentes',
    'accidente_edit_title' => 'Editar especificación accidente',
    'accidente_create_title' => 'Crear especificación accidente',

    'idAccidente_header' => 'Número de accidente',
    'fechaAccidente_header' => 'Fecha del accidente',
    'lugarAccidente_header' => 'Lugar del accidente',
    'porcentajeDanio_header' => 'Porcentaje de daño en el accidente',
    'coberturaSiniestro_header' => 'Cobertura del siniestro (€)',

    'idAccidente_placeholder' => 'Introduce el número de accidente',
    'fechaAccidente_placeholder' => 'Introduce la fecha del accidente',
    'lugarAccidente_placeholder' => 'Introduce el lugar del accidente',
    'porcentajeDanio_placeholder' => 'Introduce el porcenaje de daño en el accidente',
    'coberturaSiniestro_placeholder' => 'Introduce la cobertura del siniestro',
   
    'search_idAccidente_placeholder' => 'Número de accidente a buscar...',
    'search_fechaAccidente_placeholder' => 'Fecha del accidente a buscar...',
    'search_lugarAccidente_placeholder' => 'Lugar del accidente a buscar...',
    'search_porcentajeDanio_placeholder' => 'Porcenaje de daño en el accidente a buscar...',
    'search_coberturaSiniestro_placeholder' => 'Cobertura del siniestro a buscar...',

    'no_accidentes' => 'No existen especificaciones de accidentes',
];
