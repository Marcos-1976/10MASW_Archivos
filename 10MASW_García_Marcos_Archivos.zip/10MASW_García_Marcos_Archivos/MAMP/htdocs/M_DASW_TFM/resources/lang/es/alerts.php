<?php
return [
    // General
    'successful_message' => 'Tarea realizada con éxito.',
    'error_message' => 'Algo salió mal.',
    'warning_message' => 'Advertencia',
    'info_message' => 'Información extra',

    // Clientes
    'clientes_created_successfully' => 'Cliente creado correctamente.',
    'clientes_updated_successfully' => 'Cliente actualizado correctamente.',
    'clientes_deleted_successfully' => 'Cliente borrado correctamente.',
    'clientes_deleted_error'=> 'Cliente no borrado.',

    // Lugares
    'lugars_created_successfully' => 'Lugar creado correctamente.',
    'lugars_updated_successfully' => 'Lugar actualizado correctamente.',
    'lugars_deleted_successfully' => 'Lugar borrado correctamente.',
    'lugars_deleted_error'=> 'Lugar no borrado.',

    // Compras
    'compras_created_successfully' => 'Compra del cliente creada correctamente.',
    'compras_updated_successfully' => 'Compra del cliente actualizada correctamente.',
    'compras_deleted_successfully' => 'Compra del cliente borrada correctamente.',
    'compras_deleted_error'=> 'Compra del cliente no borrada.',

    // Pólizas
    'polizas_created_successfully' => 'Póliza creada correctamente.',
    'polizas_updated_successfully' => 'Póliza actualizada correctamente.',
    'polizas_deleted_successfully' => 'Póliza borrada correctamente.',
    'polizas_deleted_error'=> 'Póliza no borrada.',

    // Aseguras
    'aseguras_created_successfully' => 'Propietario creado correctamente.',
    'aseguras_updated_successfully' => 'Propietario actualizado correctamente.',
    'aseguras_deleted_successfully' => 'Propietario borrado correctamente.',
    'aseguras_deleted_error'=> 'Propietario no borrado.',

    // Vehículos
    'vehiculos_created_successfully' => 'Vehículo creado correctamente.',
    'vehiculos_updated_successfully' => 'Vehículo actualizado correctamente.',
    'vehiculos_deleted_successfully' => 'Vehículo borrado correctamente.',
    'vehiculos_deleted_error'=> 'Vehículo no borrado.',

    // Modelos
    'modelos_created_successfully' => 'Modelo creado correctamente.',
    'modelos_updated_successfully' => 'Modelo actualizado correctamente.',
    'modelos_deleted_successfully' => 'Modelo borrado correctamente.',
    'modelos_deleted_error'=> 'Modelo no borrado.',

    // Vehículos accidentados
    'hatenidos_created_successfully' => 'Vehículo accidentado creado correctamente.',
    'hatenidos_updated_successfully' => 'Vehículo accidentado actualizado correctamente.',
    'hatenidos_deleted_successfully' => 'Vehículo accidentado borrado correctamente.',
    'hatenidos_deleted_error'=> 'Vehículo accidentado no borrado.',

    // Especificación de accidentes
    'accidentes_created_successfully' => 'Especificación de accidente creado correctamente.',
    'accidentes_updated_successfully' => 'Especificación de accidente actualizado correctamente.',
    'accidentes_deleted_successfully' => 'Especificación de accidente borrado correctamente.',
    'accidentes_deleted_error'=> 'Especificación de accidente no borrado.',
];
