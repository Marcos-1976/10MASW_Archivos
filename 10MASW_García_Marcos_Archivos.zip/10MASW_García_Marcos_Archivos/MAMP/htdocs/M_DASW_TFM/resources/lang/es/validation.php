<?php

return [

    'alpha' => 'El valor de :attribute solo puede contener letras.',
    'confirmed' => 'La confirmación de contraseña ha fallado.',
    'email' => 'El valor de :attribute debe ser un correo electrónico válido.',
    'exists' => 'La selección :attribute es inválida.',
    'max' => [
        'numeric' => 'El valor de :attribute no puede ser más grande que :max.',
    ],
    'min' => [
        'numeric' => 'El valor de:attribute debe tener al menos :min.',
        'string' => 'El valor de :attribute debe tener al menos :min caracteres.',
    ],
    'numeric' => 'El valor de :attribute debe ser un número.',
    'password' => 'La contraseña es incorrecta.',
    'required' => 'El valor de :attribute es un campo obligatorio.',
    'size' => [
        'numeric' => 'El valor de :attribute debe ser :size.',
        'string' => 'El valor de :attribute debe tener :size caracteres.',
    ],
    'regex' => 'El formato de :attribute es inválido.',
    'unique' => 'El valor de :attribute no está disponible.',
    'date_format' => 'El valor de :attribute no tiene el formato :format.'

];
