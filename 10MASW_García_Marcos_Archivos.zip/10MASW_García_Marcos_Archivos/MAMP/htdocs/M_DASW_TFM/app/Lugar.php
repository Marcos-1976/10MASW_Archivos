<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lugar extends Model
{
    // Para poder añadir una fila en una BD externa:
    public $timestamps = false; // By default timestamp is true.

    // Ya que la clave principal no es la de defecto "id" y además ésta no es solo numérica:
    protected $primaryKey = 'residencia';
    public $incrementing = false;
}
