<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Poliza extends Model
{
   // Para poder añadir una fila en una BD externa:
   public $timestamps = false; // By default timestamp is true.

   // Ya que la clave principal no es la de defecto "id":
   protected $primaryKey = 'idPoliza';
}
