<?php
/**
 * Created by PhpStorm.
 * User: raul
 * Date: 2/11/18
 * Time: 10:39
 */

namespace App;

class ErrorSession
{
    public const SUCCESS_COD = 'success';
    public const INFO_COD = 'info';
    public const WARNING_COD = 'warning';
    public const ERROR_COD = 'danger';
}
