<?php

namespace App\Rules;

use Hamcrest\Type\IsNumeric;
use Illuminate\Contracts\Validation\Rule;
use Illuminate\Support\Str;

class CheckPhone implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $international = Str::substr($value, 0, 1); // Función predefinida/nativa de PHP que devuelve una cadena de caracteres desde el inicio al final indicado.
        if (Str::contains($international, "+")) { // Función que verifica si una cadena contiene una subcadena específica.
            $number = Str::substr($value, 1);
                if (Str::length($value) >= 9 && Str::length($value)<= 12) { // Función que cuenta los elmentos de una cadena.
                    if (is_numeric(Str::length($value))) { // Función que devuelve "true" si es un número.
                        return $number;
                    }
            }
        } else if (Str::length($value) >= 9 && Str::length($value)<= 12 && (is_numeric($international))) {
            if (is_numeric($value)) {
                return $value;
            }
        }
    }    
    
    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'El Teléfono no tiene el formato correcto.';
    }
}
