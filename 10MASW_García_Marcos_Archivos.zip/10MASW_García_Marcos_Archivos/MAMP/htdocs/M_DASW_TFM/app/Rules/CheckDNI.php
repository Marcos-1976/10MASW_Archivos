<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;
use Illuminate\Support\Str;

class CheckDNI implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $number = Str::substr($value, 0, 8); // Función predefinida/nativa de PHP que devuelve una cadena de caracteres desde el inicio al final indicado.
        if (is_numeric($number)) { // Función que devuelve "true" si es un número.
            $lastVal = Str::substr($value, 8);
            if (preg_match('/^[0-9]$/', $lastVal)) { // Función que realiza una comparación con una expresión regular.
            } else return $value; // Cadena no coincide con la expresión regular.
        }
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'El D.N.I. no tiene un formato válido.';
    }
}
