<?php
 
 namespace App\Http\Controllers;

 use App\Http\Controllers\Controller;
 use App\Modelo;
 use Illuminate\Http\Request;
 use Illuminate\Support\Facades\Validator;
 use Illuminate\Support\Facades\Lang;
 
 class ModeloController extends Controller 
 {
    const PAGINATE_SIZE = 5;
    public function index(Request $request) {
        $modeloIdModelo = $request->modeloIdModelo;
        $modeloTipoCarroceria = $request->modeloTipoCarroceria;
        $modeloFabricante = $request->modeloFabricante;
        $modeloPotencia = $request->modeloPotencia;
        
        if ($modeloIdModelo != null) {
            $modelos = Modelo::where('idModelo', 'like', '%'.$modeloIdModelo.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($modeloTipoCarroceria != null) {
            $modelos = Modelo::where('tipoCarroceria', 'like', '%'.$modeloTipoCarroceria.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($modeloFabricante != null) {
            $modelos = Modelo::where('fabricante', 'like', '%'.$modeloFabricante.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($modeloPotencia != null) {
            $modelos = Modelo::where('tipoCarroceria', 'like', '%'.$modeloPotencia.'%')->paginate(self::PAGINATE_SIZE);
        } else {
            $modelos = Modelo::orderBy('idModelo', 'ASC')->paginate(self::PAGINATE_SIZE);
        }

        return view('modelos.index', ['modelos'=>$modelos, 'modeloIdModelo'=>$modeloIdModelo, 'modeloTipoCarroceria'=>$modeloTipoCarroceria, 'modeloFabricante'=>$modeloFabricante, 'modeloPotencia'=>$modeloPotencia]);
    }

    public function create() {
        return view('modelos.create');
    }

    public function store(Request $request) {
        $this->validateModelo($request)->validate();
        
        $modelo = new Modelo();
        $modelo->idModelo = $request->modeloIdModelo;
        $modelo->tipoCarroceria = $request->modeloTipoCarroceria;
        $modelo->fabricante = $request->modeloFabricante;
        $modelo->carroceria = $request->modeloPotencia;
        $modelo->save();

        return redirect()->route('modelos.index')->with('success', Lang::get('alerts.modelos_created_successfully'));
    }

    public function edit(Modelo $modelo) {
        return view('modelos.create', ['modelo'=>$modelo]);
    }

    public function update(Request $request, Modelo $modelo) {
        $this->validateModelo($request)->validate();
        
        $modelo->idModelo = $request->modeloIdModelo;
        $modelo->tipoCarroceria = $request->modeloTipoCarroceria;
        $modelo->fabricante = $request->modeloFabricante;
        $modelo->carroceria = $request->modeloPotencia;
        $modelo->save();

        return redirect()->route('modelos.index')->with('success', Lang::get('alerts.modelos_updated_successfully'));
    }
    
    public function delete(Request $request, Modelo $modelo) {
        if($modelo != null) {
            $modelo->delete();
            return redirect()->route('modelos.index')->with('success', Lang::get('alerts.modelos_deleted_successfully'));
        }
        return redirect()->route('modelos.index')->with('error', Lang::get('alerts.modelos_deleted_error'));
    }

    public function validateModelo($request) {
        return Validator::make($request->all(), [
            'modeloIdModelo' => ['required', 'string', 'max:20'],
            'modeloTipoCarroceria' => ['required', 'string', 'max:20'],
            'modeloFabricante' => ['required', 'string', 'max:20'],
            'modeloPotencia' => ['required', 'integer'],
        ]);
    }
 }
 