<?php
 
 namespace App\Http\Controllers;

 use App\Http\Controllers\Controller;
 use App\Compra;
 use App\Cliente;
 use App\Poliza;
 use Illuminate\Http\Request;
 use Illuminate\Support\Facades\Validator;
 use Illuminate\Support\Facades\Lang;
 
 class CompraController extends Controller 
 {
    const PAGINATE_SIZE = 5;
    public function index(Request $request) {
        $compraDNI = $request->compraDNI;
        $compraIdPoliza = $request->compraIdPoliza;

        if ($compraDNI != null && $compraDNI != "-1") {
            $compras = Compra::where('DNI', 'like', '%'.$compraDNI.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($compraIdPoliza != null && $compraIdPoliza != "-1") {
            $compras = Compra::where('idPoliza', 'like', '%'.$compraIdPoliza.'%')->paginate(self::PAGINATE_SIZE);
        } else {
            $compras = Compra::orderBy('idPoliza', 'ASC')->paginate(self::PAGINATE_SIZE);
        }
        
        foreach ($compras as $compra) {
            // Para que aparezca la selección de "clientes" y en la columna "DNI" se muestre también el "nombre" ("first" filtra la consulta obteniendo un solo elemento en vez de todas las filas):
            $compra->cliente = Cliente::where('DNI', '=', $compra->DNI)->first();
            
            // Para que aparezca la selección de "polizas":
            $compra->poliza = Poliza::where('idPoliza', '=', $compra->idPoliza)->first();
        }
        // Para que aparezca la selección de "clientes" en orden ascendente:
        $clientes = Cliente::orderBy('DNI', 'ASC')->get();
        // Para que aparezca la selección de "polizas" en orden ascendente:
        $polizas = Poliza::orderBy('idPoliza', 'ASC')->get();

        return view('compras.index', ['compras'=>$compras, 'clientes'=>$clientes, 'polizas'=>$polizas, 'compraDNI'=>$compraDNI, 'compraIdPoliza'=>$compraIdPoliza]);
    }

    public function create() { // Al pulsar el botón "Crear compra" o también "Editar".
        $clientes = Cliente::orderBy('DNI', 'ASC')->get();
        $polizas = Poliza::orderBy('idPoliza', 'ASC')->get();

        return view('compras.create', ['clientes'=>$clientes, 'polizas'=>$polizas]);
    }

    public function store(Request $request) { // Al pulsar el botón "Crear". Guardado en la BD de un nuevo registro.
        $this->validateCliente($request)->validate();

        $compra = new Compra();

        $compra->DNI = $request->compraDNI; // Nombre del campo en la BD.
        $compra->idPoliza = $request->compraIdPoliza;
        
        $compra->save();

        return redirect()->route('compras.index')->with('success', Lang::get('alerts.compras_created_successfully'));
    }

    public function edit(Compra $compra) { // Al pulsar el botón "Editar".
        $clientes = Cliente::orderBy('DNI', 'ASC')->get();
        $polizas = Poliza::orderBy('idPoliza', 'ASC')->get();

        return view('compras.create', ['compra'=>$compra, 'clientes'=>$clientes, 'polizas'=>$polizas]);
    }

    public function update(Request $request, Compra $compra) { // Al pulsar el botón "Guardar". Guardado en la BD de la modificación de un registro.
        $this->validateCliente($request)->validate();
        
        $compra->DNI = $request->compraDNI; // Nombre del campo en la BD.
        $compra->idPoliza = $request->compraIdPoliza;
        
        $compra->save();
        
        return redirect()->route('compras.index')->with('success', Lang::get('alerts.compras_updated_successfully'));
    }
    
    public function delete(Request $request, Compra $compra) { // Al pulsar el botón "Borrar".
        if($compra != null) {
            $compra->delete();
            return redirect()->route('compras.index')->with('success', Lang::get('alerts.compras_deleted_successfully'));
        }
        return redirect()->route('compras.index')->with('error', Lang::get('alerts.compras_deleted_error'));
    }

    public function validateCliente($request) {
        return Validator::make($request->all(), [
            'compraDNI' => ['required', 'exists:clientes,DNI'],
            'compraIdPoliza' => ['required', 'exists:polizas,idPoliza'],
        ]);
    }
 }
 