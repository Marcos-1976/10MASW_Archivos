<?php
 
 namespace App\Http\Controllers;

 use App\Http\Controllers\Controller;
 use App\Poliza;
 use Illuminate\Http\Request;
 use Illuminate\Support\Facades\Validator;
 use Illuminate\Support\Facades\Lang;
 use Illuminate\Support\Carbon;

 class PolizaController extends Controller 
 {
    const PAGINATE_SIZE = 5;
    public function index(Request $request) {
        $polizaIdPoliza = $request->polizaIdPoliza;
        $polizaPrima = $request->polizaPrima;
        $polizaFechaAlta= $request->polizaFechaAlta;
        $polizaFechaVencimiento = $request->polizaFechaNacimiento;
        $polizaTipo = $request->polizaTipo;

        if ($polizaIdPoliza != null) {
            $polizas = Poliza::where('idPoliza', 'like', '%'.$polizaIdPoliza.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($polizaPrima != null) {
            $polizas = Poliza::where('prima', 'like', '%'.$polizaPrima.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($polizaFechaAlta != null) {
            $polizas = Poliza::whereDate('fechaAlta', 'like', '%'. Carbon::parse($polizaFechaAlta)->format('Y-m-d') . '%')->paginate(self::PAGINATE_SIZE);
        } else if ($polizaFechaVencimiento != null) {
            $polizas = Poliza::whereDate('fechaVencimiento', 'like', '%'. Carbon::parse($polizaFechaVencimiento)->format('Y-m-d') . '%')->paginate(self::PAGINATE_SIZE);
        } else if ($polizaTipo != null) {
            $polizas = Poliza::where('tipoPoliza', 'like', '%'.$polizaTipo.'%')->paginate(self::PAGINATE_SIZE);
        } else {
            $polizas = Poliza::orderBy('idPoliza', 'ASC')->paginate(self::PAGINATE_SIZE);
        }

        foreach ($polizas as $poliza) {
            $poliza->fechaAlta= Carbon::parse($poliza->fechaAlta)->format('d-m-Y');
            $poliza->fechaVencimiento= Carbon::parse($poliza->fechaVencimiento)->format('d-m-Y');
        }

        return view('polizas.index', ['polizas'=>$polizas, 'polizaIdPoliza'=>$polizaIdPoliza, 'polizaPrima'=>$polizaPrima, 'polizaFechaAlta'=>$polizaFechaAlta, 'polizaFechaVencimiento'=>$polizaFechaVencimiento, 'polizaTipo'=>$polizaTipo]);
    }

    public function create() {
        return view('polizas.create');
    }

    public function store(Request $request) {
        $this->validatePoliza($request)->validate();
        
        $poliza = new Poliza();
        $poliza->idPoliza = $request->polizaIdPoliza;
        $poliza->prima = $request->polizaPrima;
        $poliza->fechaAlta = Carbon::parse($request->polizaFechaAlta)->format('Y-m-d');
        $poliza->fechaVencimiento = Carbon::parse($request->polizaFechaVencimiento)->format('Y-m-d');
        $poliza->tipoPoliza = $request->polizaTipo;
        $poliza->save();

        return redirect()->route('polizas.index')->with('success', Lang::get('alerts.polizas_created_successfully'));
    }

    public function edit(Poliza $poliza) {
        $poliza->fechaAlta = Carbon::parse($poliza->fechaAlta)->format('d-m-Y');
        $poliza->fechaVencimiento = Carbon::parse($poliza->fechaVencimiento)->format('d-m-Y');

        return view('polizas.create', ['poliza'=>$poliza]);
    }

    public function update(Request $request, Poliza $poliza) {
        $this->validatePoliza($request)->validate();
        
        //$poliza->idPoliza = $request->polizaIdPoliza;
        $poliza->prima = $request->polizaPrima;
        $poliza->fechaAlta = Carbon::parse($request->polizaFechaAlta)->format('Y-m-d');
        $poliza->fechaVencimiento = Carbon::parse($request->polizaFechaVencimiento)->format('Y-m-d');
        $poliza->tipoPoliza = $request->polizaTipo;
        $poliza->save();

        return redirect()->route('polizas.index')->with('success', Lang::get('alerts.polizas_updated_successfully'));
    }
    
    public function delete(Request $request, Poliza $poliza) {
        if($poliza != null) {
            $poliza->delete();
            return redirect()->route('polizas.index')->with('success', Lang::get('alerts.polizas_deleted_successfully'));
        }
        return redirect()->route('polizas.index')->with('error', Lang::get('alerts.polizas_deleted_error'));
    }

    public function validatePoliza($request) {
        return Validator::make($request->all(), [
            //'polizaIdPoliza' => ['required', 'integer'],
            'polizaPrima' => ['required', 'integer'],
            'polizaFechaAlta' => ['required', 'date_format:d-m-Y'],
            'polizaFechaVencimiento' => ['required', 'date_format:d-m-Y'],
            'polizaTipo' => ['required', 'string', 'max:10'],
        ]);
    }
 }
 