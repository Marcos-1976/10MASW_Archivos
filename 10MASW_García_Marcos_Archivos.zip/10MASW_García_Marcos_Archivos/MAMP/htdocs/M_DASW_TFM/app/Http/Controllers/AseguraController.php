<?php
 
 namespace App\Http\Controllers;

 use App\Http\Controllers\Controller;
 use App\Asegura;
 use App\Cliente;
 use App\Vehiculo;
 use Illuminate\Http\Request;
 use Illuminate\Support\Facades\Validator;
 use Illuminate\Support\Facades\Lang;
 
 class AseguraController extends Controller 
 {
    const PAGINATE_SIZE = 5;
    public function index(Request $request) {
        $aseguraDNI = $request->aseguraDNI;
        $aseguraMatricula = $request->aseguraMatricula;

        if ($aseguraDNI != null && $aseguraDNI != "-1") {
            $aseguras = Asegura::where('DNI', 'like', '%'.$aseguraDNI.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($aseguraMatricula != null && $aseguraMatricula != "-1") {
            $aseguras = Asegura::where('matricula', 'like', '%'.$aseguraMatricula.'%')->paginate(self::PAGINATE_SIZE);
        } else {
            $aseguras = Asegura::orderBy('matricula', 'ASC')->paginate(self::PAGINATE_SIZE);
        }
        
        foreach ($aseguras as $asegura) {
            // Para que aparezca la selección de "clientes" y en la columna "DNI" se muestre también el "nombre" ("first" filtra la consulta obteniendo un solo elemento en vez de todas las filas):
            $asegura->cliente = Cliente::where('DNI', '=', $asegura->DNI)->first();
            
            // Para que aparezca la selección de "vehiculos":
            $asegura->vehiculo = Vehiculo::where('matricula', '=', $asegura->matricula)->first();
        }
        // Para que aparezca la selección de "clientes" en orden ascendente:
        $clientes = Cliente::orderBy('DNI', 'ASC')->get();
        // Para que aparezca la selección de "vehiculos" en orden ascendente:
        $vehiculos = Vehiculo::orderBy('matricula', 'ASC')->get();

        return view('aseguras.index', ['aseguras'=>$aseguras, 'clientes'=>$clientes, 'vehiculos'=>$vehiculos, 'aseguraDNI'=>$aseguraDNI, 'aseguraMatricula'=>$aseguraMatricula]);
    }

    public function create() { // Al pulsar el botón "Crear asegura" o también "Editar".
        $clientes = Cliente::orderBy('DNI', 'ASC')->get();
        $vehiculos = Vehiculo::orderBy('matricula', 'ASC')->get();

        return view('aseguras.create', ['clientes'=>$clientes, 'vehiculos'=>$vehiculos]);
    }

    public function store(Request $request) { // Al pulsar el botón "Crear". Guardado en la BD de un nuevo registro.
        $this->validateCliente($request)->validate();

        $asegura = new Asegura();

        $asegura->DNI = $request->aseguraDNI; // Nombre del campo en la BD.
        $asegura->matricula = $request->aseguraMatricula;
        
        $asegura->save();

        return redirect()->route('aseguras.index')->with('success', Lang::get('alerts.aseguras_created_successfully'));
    }

    public function edit(Asegura $asegura) { // Al pulsar el botón "Editar".
        $clientes = Cliente::orderBy('DNI', 'ASC')->get();
        $vehiculos = Vehiculo::orderBy('matricula', 'ASC')->get();

        return view('aseguras.create', ['asegura'=>$asegura, 'clientes'=>$clientes, 'vehiculos'=>$vehiculos]);
    }

    public function update(Request $request, Asegura $asegura) { // Al pulsar el botón "Guardar". Guardado en la BD de la modificación de un registro.
        $this->validateCliente($request)->validate();
        
        $asegura->DNI = $request->aseguraDNI; // Nombre del campo en la BD.
        $asegura->matricula = $request->aseguraMatricula;
        
        $asegura->save();
        
        return redirect()->route('aseguras.index')->with('success', Lang::get('alerts.aseguras_updated_successfully'));
    }
    
    public function delete(Request $request, Asegura $asegura) { // Al pulsar el botón "Borrar".
        if($asegura != null) {
            $asegura->delete();
            return redirect()->route('aseguras.index')->with('success', Lang::get('alerts.aseguras_deleted_successfully'));
        }
        return redirect()->route('aseguras.index')->with('error', Lang::get('alerts.aseguras_deleted_error'));
    }

    public function validateCliente($request) {
        return Validator::make($request->all(), [
            'aseguraDNI' => ['required', 'exists:clientes,DNI'],
            'aseguraMatricula' => ['required', 'exists:vehiculos,matricula'],
        ]);
    }
 }
 