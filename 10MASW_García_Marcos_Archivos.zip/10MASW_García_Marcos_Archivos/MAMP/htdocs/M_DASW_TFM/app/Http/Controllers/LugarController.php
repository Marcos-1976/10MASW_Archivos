<?php
 
 namespace App\Http\Controllers;

 use App\Http\Controllers\Controller;
 use App\Lugar;
 use Illuminate\Http\Request;
 use Illuminate\Support\Facades\Validator;
 use Illuminate\Support\Facades\Lang;
 
 class LugarController extends Controller 
 {
    const PAGINATE_SIZE = 5;
    public function index(Request $request) {
        $lugarResidencia = $request->lugarResidencia;
        $lugarDistritoPostal = $request->lugarDistritoPostal;
        
        if ($lugarResidencia != null) {
            $lugars = Lugar::where('residencia', 'like', '%'.$lugarResidencia.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($lugarDistritoPostal != null) {
            $lugars = Lugar::where('distritoPostal', 'like', '%'.$lugarDistritoPostal.'%')->paginate(self::PAGINATE_SIZE);
        } else {
            $lugars = Lugar::orderBy('distritoPostal', 'ASC')->paginate(self::PAGINATE_SIZE);
        }

        return view('lugars.index', ['lugars'=>$lugars, 'lugarResidencia'=>$lugarResidencia, 'lugarDistritoPostal'=>$lugarDistritoPostal]);
    }

    public function create() {
        return view('lugars.create');
    }

    public function store(Request $request) {
        $this->validateLugar($request)->validate();
        
        $lugar = new Lugar();
        $lugar->residencia = $request->lugarResidencia;
        $lugar->distritoPostal = $request->lugarDistritoPostal;
        $lugar->save();

        return redirect()->route('lugars.index')->with('success', Lang::get('alerts.lugars_created_successfully'));
    }

    public function edit(Lugar $lugar) {
        return view('lugars.create', ['lugar'=>$lugar]);
    }

    public function update(Request $request, Lugar $lugar) {
        $this->validateLugar($request)->validate();
        
        $lugar->residencia = $request->lugarResidencia;
        $lugar->distritoPostal = $request->lugarDistritoPostal;
        $lugar->save();

        return redirect()->route('lugars.index')->with('success', Lang::get('alerts.lugars_updated_successfully'));
    }
    
    public function delete(Request $request, Lugar $lugar) {
        if($lugar != null) {
            $lugar->delete();
            return redirect()->route('lugars.index')->with('success', Lang::get('alerts.lugars_deleted_successfully'));
        }
        return redirect()->route('lugars.index')->with('error', Lang::get('alerts.lugars_deleted_error'));
    }
    
    public function validateLugar($request) {
        return Validator::make($request->all(), [
            'lugarResidencia' => ['required', 'string', 'max:50', 'min:5'],
            'lugarDistritoPostal' => ['required', 'integer', 'size:5'],
        ]);
    }
 }
 