<?php
 
 namespace App\Http\Controllers;

 use App\Http\Controllers\Controller;
 use App\Cliente;
 use App\Lugar;
 use App\Rules\CheckDNI;
 use App\Rules\CheckPhone;
 use App\Rules\CheckEmail;
 //use App\Rules\CheckIBAN;
 use Illuminate\Http\Request;
 use Illuminate\Support\Facades\Validator;
 use Illuminate\Support\Facades\Lang;
 use Illuminate\Support\Carbon;
 
 class ClienteController extends Controller 
 {
    const PAGINATE_SIZE = 5;
    public function index(Request $request) {
        $clienteDNI = $request->clienteDNI;
        $clienteNombre = $request->clienteNombre;
        $clienteTelefono = $request->clienteTelefono;
        $clienteEmail = $request->clienteEmail;
        //$clienteIBAN = $request->clienteIBAN;
        $clienteFechaNacimiento = $request->clienteFechaNacimiento;
        $clienteResidencia = $request->clienteResidencia;

        if ($clienteDNI != null) {
            $clientes = Cliente::where('DNI', 'like', '%'.$clienteDNI.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($clienteNombre != null) {
            $clientes = Cliente::where('nombre', 'like', '%'.$clienteNombre.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($clienteTelefono != null) {
            $clientes = Cliente::where('telefonoCliente', 'like', '%'.$clienteTelefono.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($clienteEmail != null) {
            $clientes = Cliente::where('eMail', 'like', '%'.$clienteEmail.'%')->paginate(self::PAGINATE_SIZE);
        //} else if ($clienteIBAN != null) {
        //    $clientes = Cliente::where('IBAN', 'like', '%'.$clienteIBAN.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($clienteFechaNacimiento != null) {
            // Se comparan 2 fechas con el mismo formato, la fecha introducida en el formato "d-m-Y" se parsea al formato "Y-m-d" ya que mySQL solo guarda el dato de tipo DATE en el formato "Y-m-d".
            $clientes = Cliente::whereDate('fechaNacimiento', 'like', '%'. Carbon::parse($clienteFechaNacimiento)->format('Y-m-d') . '%')->paginate(self::PAGINATE_SIZE);
        } else if ($clienteResidencia != null && $clienteResidencia != "-1") {
            $clientes = Cliente::where('residencia', 'like', '%'.$clienteResidencia.'%')->paginate(self::PAGINATE_SIZE);
        } else {
            $clientes = Cliente::orderBy('nombre', 'ASC')->paginate(self::PAGINATE_SIZE);
        }
        
        // Para que la columna "fechaNacimiento" se muestre en el formato "d-m-Y" (ya que mySQL solo guarda el dato de tipo DATE en el formato "Y-m-d"):
        foreach ($clientes as $cliente) {
            $cliente->fechaNacimiento = Carbon::parse($cliente->fechaNacimiento)->format('d-m-Y');
        }

        // Para que la selección de "lugars" y en la columna "residencia" se muestre también el "distrito postal" ("first" filtra la consulta obteniendo un solo elemento en vez de todas las filas):
        foreach ($clientes as $cliente) {
            $cliente->lugar = Lugar::where('residencia', '=', $cliente->residencia)->first();
        }
        // Para que aparezca la selección de "lugars" en orden ascendente:
        $lugars = Lugar::orderBy('residencia', 'ASC')->get();
        
        return view('clientes.index', ['clientes'=>$clientes, 'lugars'=>$lugars, 'clienteDNI'=>$clienteDNI, 'clienteNombre'=>$clienteNombre, 'clienteTelefono'=>$clienteTelefono, 'clienteEmail'=>$clienteEmail, 'clienteFechaNacimiento'=>$clienteFechaNacimiento, 'clienteResidencia'=>$clienteResidencia]);
    }

    public function create() { // Al pulsar el botón "Crear cliente" o también "Editar".
        $lugars = Lugar::orderBy('residencia', 'ASC')->get();
        
        return view('clientes.create', ['lugars'=>$lugars]);
    }

    public function store(Request $request) { // Al pulsar el botón "Crear". Guardado en la BD de un nuevo registro.
        $this->validateCliente($request)->validate();
        
        $cliente = new Cliente();

        $cliente->DNI = $request->clienteDNI; // Nombre del campo en la BD.
        $cliente->nombre = $request->clienteNombre;
        $cliente->telefonoCliente = $request->clienteTelefono;
        $cliente->eMail = $request->clienteEmail;
        //$cliente->IBAN = $request->clienteIBAN;
        // Guarda la fecha en el formato del tipo DATE de mySQL ("Y-m-d"):
        $cliente->fechaNacimiento = Carbon::parse($request->clienteFechaNacimiento)->format('Y-m-d');
        $cliente->residencia = $request->clienteResidencia;
        
        $cliente->save();

        return redirect()->route('clientes.index')->with('success', Lang::get('alerts.clientes_created_successfully'));
    }

    public function edit(Cliente $cliente) { // Al pulsar el botón "Editar".
        $lugars = Lugar::orderBy('residencia', 'ASC')->get();

        // Para que la columna "fechaNacimiento" aparezca en el formato "d-m-Y" (ya que mySQL solo guarda el dato de tipo DATE en el formato "Y-m-d"):
        $cliente->fechaNacimiento = Carbon::parse($cliente->fechaNacimiento)->format('d-m-Y');

        return view('clientes.create', ['cliente'=>$cliente, 'lugars'=>$lugars]);
    }

    public function update(Request $request, Cliente $cliente) { // Al pulsar el botón "Guardar". Guardado en la BD de la modificación de un registro.
        $this->validateCliente($request)->validate();
        
        $cliente->DNI = $request->clienteDNI; // Nombre del campo en la BD.
        $cliente->nombre = $request->clienteNombre;
        $cliente->telefonoCliente = $request->clienteTelefono;
        $cliente->eMail = $request->clienteEmail;
        //$cliente->IBAN = $request->clienteIBAN;
        // Guarda la fecha en el formato del tipo DATE de mySQL ("Y-m-d"):
        $cliente->fechaNacimiento = Carbon::parse($request->clienteFechaNacimiento)->format('Y-m-d');
        $cliente->residencia = $request->clienteResidencia;
        
        $cliente->save();
        
        return redirect()->route('clientes.index')->with('success', Lang::get('alerts.clientes_updated_successfully'));
    }
    
    public function delete(Request $request, Cliente $cliente) { // Al pulsar el botón "Borrar".
        if($cliente != null) {
            $cliente->delete();
            return redirect()->route('clientes.index')->with('success', Lang::get('alerts.clientes_deleted_successfully'));
        }
        return redirect()->route('clientes.index')->with('error', Lang::get('alerts.clientes_deleted_error'));
    }

    public function validateCliente($request) {
        return Validator::make($request->all(), [
            'clienteDNI' => ['required', 'string', 'size:9', new CheckDNI],
            'clienteNombre' => ['required', 'string', 'max:20', 'min:2'],
            'clienteTelefono' => ['required', 'string', 'size:12', new CheckPhone],
            'clienteEmail' => ['required', 'string', 'max:20', new CheckEmail],
            //'clienteIBAN' => ['nullable', 'string', 'size:24', new CheckIBAN],
            'clienteFechaNacimiento' => ['required', 'date_format:d-m-Y'],
            'clienteResidencia' => ['required', 'exists:lugars,residencia'],
        ]);
    }
 }
 