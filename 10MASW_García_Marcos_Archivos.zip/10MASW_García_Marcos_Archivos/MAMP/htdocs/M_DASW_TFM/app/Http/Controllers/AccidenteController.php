<?php
 
 namespace App\Http\Controllers;

 use App\Http\Controllers\Controller;
 use App\Accidente;
 use Illuminate\Http\Request;
 use Illuminate\Support\Facades\Validator;
 use Illuminate\Support\Facades\Lang;
 use Illuminate\Support\Carbon;
  
 class AccidenteController extends Controller 
 {
    const PAGINATE_SIZE = 5;
    public function index(Request $request) {
        $accidenteIdAccidente = $request->accidenteIdAccidente;
        $accidenteFechaAccidente = $request->accidenteFechaAccidente;
        $accidenteLugarAccidente = $request->accidenteLugarAccidente;
        $accidentePorcentajeDanio = $request->accidentePorcentajeDanio;
        $accidenteCoberturaSiniestro = $request->accidenteCoberturaSiniestro;
        
        if ($accidenteIdAccidente != null) {
            $accidentes = Accidente::where('idAccidente', 'like', '%'.$accidenteIdAccidente.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($accidenteFechaAccidente != null) {
            // Se comparan 2 fechas con el mismo formato, la fecha introducida en el formato "d-m-Y" se parsea al formato "Y-m-d" ya que mySQL solo guarda el dato de tipo DATE en el formato "Y-m-d".
            $accidentes = Accidente::whereDate('fechaAccidente', 'like', '%'. Carbon::parse($accidenteFechaAccidente)->format('Y-m-d') . '%')->paginate(self::PAGINATE_SIZE);
        } else if ($accidenteLugarAccidente != null) {
            $accidentes = Accidente::where('lugarAccidente', 'like', '%'.$accidenteLugarAccidente.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($accidentePorcentajeDanio != null) {
            $accidentes = Accidente::where('porcentajeDanio', 'like', '%'.$accidentePorcentajeDanio.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($accidenteCoberturaSiniestro != null) {
            $accidentes = Accidente::where('coberturaSiniestro', 'like', '%'.$accidenteCoberturaSiniestro.'%')->paginate(self::PAGINATE_SIZE);
        } else {
            $accidentes = Accidente::orderBy('idAccidente', 'ASC')->paginate(self::PAGINATE_SIZE);
        }

        // Para que la columna "fechaAccidente" se muestre en el formato "d-m-Y" (ya que mySQL solo guarda el dato de tipo DATE en el formato "Y-m-d"):
        foreach ($accidentes as $accidente) {
            $accidente->fechaAccidente = Carbon::parse($accidente->fechaAccidente)->format('d-m-Y');
        }

        return view('accidentes.index', ['accidentes'=>$accidentes, 'accidenteIdAccidente'=>$accidenteIdAccidente, 'accidenteFechaAccidente'=>$accidenteFechaAccidente, 'accidenteLugarAccidente'=>$accidenteLugarAccidente, 'accidentePorcentajeDanio'=>$accidentePorcentajeDanio, 'accidenteCoberturaSiniestro'=>$accidenteCoberturaSiniestro]);
    }

    public function create() {
        return view('accidentes.create');
    }

    public function store(Request $request) {
        $this->validateAccidente($request)->validate();
        
        $accidente = new Accidente();
        
        $accidente->idAccidente = $request->accidenteIdAccidente;
        // Guarda la fecha en el formato del tipo DATE de mySQL ("Y-m-d"):
        $accidente->fechaAccidente = Carbon::parse($request->accidenteFechaAccidente)->format('Y-m-d');
        $accidente->lugarAccidente = $request->accidenteLugarAccidente;
        $accidente->porcentajeDanio = $request->accidentePorcentajeDanio;
        $accidente->coberturaSiniestro = $request->accidenteCoberturaSiniestro;
        
        $accidente->save();

        return redirect()->route('accidentes.index')->with('success', Lang::get('alerts.accidentes_created_successfully'));
    }

    public function edit(Accidente $accidente) {
        // Para que la columna "fechaAccidente" aparezca en el formato "d-m-Y" (ya que mySQL solo guarda el dato de tipo DATE en el formato "Y-m-d"):
        $accidente->fechaAccidente = Carbon::parse($accidente->fechaAccidente)->format('d-m-Y');

        return view('accidentes.create', ['accidente'=>$accidente]);
    }

    public function update(Request $request, Accidente $accidente) {
        $this->validateAccidente($request)->validate();
        
        //$accidente->idAccidente = $request->accidenteIdAccidente;
       // Guarda la fecha en el formato del tipo DATE de mySQL ("Y-m-d"):
        $accidente->fechaAccidente = Carbon::parse($request->accidenteFechaAccidente)->format('Y-m-d');
        $accidente->lugarAccidente = $request->accidenteLugarAccidente;
        $accidente->porcentajeDanio = $request->accidentePorcentajeDanio;
        $accidente->coberturaSiniestro = $request->accidenteCoberturaSiniestro;
        
        $accidente->save();

        return redirect()->route('accidentes.index')->with('success', Lang::get('alerts.accidentes_updated_successfully'));
    }
    
    public function delete(Request $request, Accidente $accidente) {
        if($accidente != null) {
            $accidente->delete();
            return redirect()->route('accidentes.index')->with('success', Lang::get('alerts.accidentes_deleted_successfully'));
        }
        return redirect()->route('accidentes.index')->with('error', Lang::get('alerts.accidentes_deleted_error'));
    }

    public function validateAccidente($request) {
        return Validator::make($request->all(), [
            //'accidenteIdAccidente' => ['required', 'integer'],
            'accidenteFechaAccidente' => ['required', 'date_format:d-m-Y'],
            'accidenteLugarAccidente' => ['required', 'string', 'max:50'],
            'accidentePorcentajeDanio' => ['required', 'integer', 'max:100'],
            'accidenteCoberturaSiniestro' => ['required', 'integer'],
        ]);
    }
 }
 