<?php
 
 namespace App\Http\Controllers;

 use App\Http\Controllers\Controller;
 use App\Hatenido;
 use App\Vehiculo;
 use App\Accidente;
 use Illuminate\Http\Request;
 use Illuminate\Support\Facades\Validator;
 use Illuminate\Support\Facades\Lang;
 
 class HatenidoController extends Controller 
 {
    const PAGINATE_SIZE = 5;
    public function index(Request $request) {
        $hatenidoMatricula = $request->hatenidoMatricula;
        $hatenidoIdAccidente = $request->hatenidoIdAccidente;

        if ($hatenidoMatricula != null && $hatenidoMatricula != "-1") {
            $hatenidos = Hatenido::where('matricula', 'like', '%'.$hatenidoMatricula.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($hatenidoIdAccidente != null && $hatenidoIdAccidente != "-1") {
            $hatenidos = Hatenido::where('idAccidente', 'like', '%'.$hatenidoIdAccidente.'%')->paginate(self::PAGINATE_SIZE);
        } else {
            $hatenidos = Hatenido::orderBy('idAccidente', 'ASC')->paginate(self::PAGINATE_SIZE);
        }
        
        foreach ($hatenidos as $hatenido) {
            // Para que aparezca la selección de "vehiculos" ("first" filtra la consulta obteniendo un solo elemento en vez de todas las filas):
            $hatenido->vehiculo = Vehiculo::where('matricula', '=', $hatenido->matricula)->first();
            
            // Para que aparezca la selección de "accidentes":
            $hatenido->accidente = Accidente::where('idAccidente', '=', $hatenido->idAccidente)->first();
        }
        // Para que aparezca la selección de "vehiculos" en orden ascendente:
        $vehiculos = Vehiculo::orderBy('matricula', 'ASC')->get();
        // Para que aparezca la selección de "accidentes" en orden ascendente:
        $accidentes = Accidente::orderBy('idAccidente', 'ASC')->get();

        return view('hatenidos.index', ['hatenidos'=>$hatenidos, 'vehiculos'=>$vehiculos, 'accidentes'=>$accidentes, 'hatenidoMatricula'=>$hatenidoMatricula, 'hatenidoIdAccidente'=>$hatenidoIdAccidente]);
    }

    public function create() { // Al pulsar el botón "Crear hatenido" o también "Editar".
        $vehiculos = Vehiculo::orderBy('matricula', 'ASC')->get();
        $accidentes = Accidente::orderBy('idAccidente', 'ASC')->get();

        return view('hatenidos.create', ['vehiculos'=>$vehiculos, 'accidentes'=>$accidentes]);
    }

    public function store(Request $request) { // Al pulsar el botón "Crear". Guardado en la BD de un nuevo registro.
        $this->validateHatenido($request)->validate();

        $hatenido = new Hatenido();

        $hatenido->matricula = $request->hatenidoMatricula; // Nombre del campo en la BD.
        $hatenido->idAccidente = $request->hatenidoIdAccidente;
        
        $hatenido->save();

        return redirect()->route('hatenidos.index')->with('success', Lang::get('alerts.hatenidos_created_successfully'));
    }

    public function edit(Hatenido $hatenido) { // Al pulsar el botón "Editar".
        $vehiculos = Vehiculo::orderBy('matricula', 'ASC')->get();
        $accidentes = Accidente::orderBy('idAccidente', 'ASC')->get();

        return view('hatenidos.create', ['hatenido'=>$hatenido, 'vehiculos'=>$vehiculos, 'accidentes'=>$accidentes]);
    }

    public function update(Request $request, Hatenido $hatenido) { // Al pulsar el botón "Guardar". Guardado en la BD de la modificación de un registro.
        $this->validateHatenido($request)->validate();
        
        $hatenido->matricula = $request->hatenidoMatricula; // Nombre del campo en la BD.
        $hatenido->idAccidente = $request->hatenidoIdAccidente;
        
        $hatenido->save();
        
        return redirect()->route('hatenidos.index')->with('success', Lang::get('alerts.hatenidos_updated_successfully'));
    }
    
    public function delete(Request $request, Hatenido $hatenido) { // Al pulsar el botón "Borrar".
        if($hatenido != null) {
            $hatenido->delete();
            return redirect()->route('hatenidos.index')->with('success', Lang::get('alerts.hatenidos_deleted_successfully'));
        }
        return redirect()->route('hatenidos.index')->with('error', Lang::get('alerts.hatenidos_deleted_error'));
    }

    public function validateHatenido($request) {
        return Validator::make($request->all(), [
            'hatenidoMatricula' => ['required', 'exists:vehiculos,matricula'],
            'hatenidoIdAccidente' => ['required', 'exists:accidentes,idAccidente'],
        ]);
    }
 }
 