<?php
 
 namespace App\Http\Controllers;

 use App\Http\Controllers\Controller;
 use App\Vehiculo;
 use App\Modelo;
 use Illuminate\Http\Request;
 use Illuminate\Support\Facades\Validator;
 use Illuminate\Support\Facades\Lang;
 use Illuminate\Support\Carbon;

 class VehiculoController extends Controller 
 {
    const PAGINATE_SIZE = 5;
    public function index(Request $request) {
        $vehiculoMatricula = $request->vehiculoMatricula;
        $vehiculoFechaMatricula = $request->vehiculoFechaMatricula;
        $vehiculoColor = $request->vehiculoColor;
        $vehiculoPrecio = $request->vehiculoPrecio;
        $vehiculoKilometraje = $request->vehiculoKilometraje;
        $vehiculoAntecedentes = $request->vehiculoAntecedentes;
        $vehiculoIdModelo = $request->vehiculoIdModelo;

        if ($vehiculoMatricula != null) {
            $vehiculos = Vehiculo::where('matricula', 'like', '%'.$vehiculoMatricula.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($vehiculoFechaMatricula != null) {
            $vehiculos = Vehiculo::whereDate('fechaMatricula', 'like', '%'. Carbon::parse($vehiculoFechaMatricula)->format('Y-m-d') . '%')->paginate(self::PAGINATE_SIZE);
        } else if ($vehiculoColor != null) {
            $vehiculos = Vehiculo::where('color', 'like', '%'.$vehiculoColor.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($vehiculoPrecio != null) {
            $vehiculos = Vehiculo::where('precio', 'like', '%'.$vehiculoPrecio.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($vehiculoKilometraje != null) {
            $vehiculos = Vehiculo::where('kilometraje', 'like', '%'.$vehiculoKilometraje.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($vehiculoAntecedentes != null) {
            $vehiculos = Vehiculo::where('antecedentes', 'like', '%'.$vehiculoAntecedentes.'%')->paginate(self::PAGINATE_SIZE);
        } else if ($vehiculoIdModelo != null && $vehiculoIdModelo != "-1") {
            $vehiculos = Vehiculo::where('idModelo', 'like', '%'.$vehiculoIdModelo.'%')->paginate(self::PAGINATE_SIZE);
        } else {
            $vehiculos = Vehiculo::orderBy('matricula', 'ASC')->paginate(self::PAGINATE_SIZE);
        }

        foreach ($vehiculos as $vehiculo) {
            $vehiculo->fechaMatricula = Carbon::parse($vehiculo->fechaMatricula)->format('d-m-Y');
        }

        foreach ($vehiculos as $vehiculo) {
            $vehiculo->modelo = Modelo::where('idModelo', '=', $vehiculo->idModelo)->first();
        }
        $modelos = Modelo::orderBy('idModelo', 'ASC')->get();

        return view('vehiculos.index', ['vehiculos'=>$vehiculos, 'modelos'=>$modelos, 'vehiculoMatricula'=>$vehiculoMatricula, 'vehiculoFechaMatricula'=>$vehiculoFechaMatricula, 'vehiculoColor'=>$vehiculoColor, 'vehiculoPrecio'=>$vehiculoPrecio, 'vehiculoKilometraje'=>$vehiculoKilometraje, 'vehiculoAntecedentes'=>$vehiculoAntecedentes, 'vehiculoIdModelo'=>$vehiculoIdModelo]);
    }

    public function create() {
        $modelos = Modelo::orderBy('idModelo', 'ASC')->get();

        return view('vehiculos.create', ['modelos'=>$modelos]);
    }

    public function store(Request $request) {
        $this->validateVehiculo($request)->validate();
        
        $vehiculo = new Vehiculo();
        $vehiculo->matricula = $request->vehiculoMatricula;
        $vehiculo->fechaMatricula = Carbon::parse($request->vehiculoFechaMatricula)->format('Y-m-d');
        $vehiculo->color = $request->vehiculoColor;
        $vehiculo->precio = $request->vehiculoPrecio;
        $vehiculo->kilometraje = $request->vehiculoKilometraje;
        $vehiculo->antecedentes = $request->vehiculoAntecedentes;
        $vehiculo->idModelo = $request->vehiculoIdModelo;
        $vehiculo->save();

        return redirect()->route('vehiculos.index')->with('success', Lang::get('alerts.vehiculos_created_successfully'));
    }

    public function edit(Vehiculo $vehiculo) {
        $modelos = Modelo::orderBy('idModelo', 'ASC')->get();

        $vehiculo->fechaMatricula = Carbon::parse($vehiculo->fechaMatricula)->format('d-m-Y');
        
        return view('vehiculos.create', ['vehiculo'=>$vehiculo, 'modelos'=>$modelos]);
    }

    public function update(Request $request, Vehiculo $vehiculo) {
        $this->validateVehiculo($request)->validate();
        
        $vehiculo->matricula = $request->vehiculoMatricula;
        $vehiculo->fechaMatricula = Carbon::parse($request->vehiculoFechaMatricula)->format('Y-m-d');
        $vehiculo->color = $request->vehiculoColor;
        $vehiculo->precio = $request->vehiculoPrecio;
        $vehiculo->kilometraje = $request->vehiculoKilometraje;
        $vehiculo->antecedentes = $request->vehiculoAntecedentes;
        $vehiculo->idModelo = $request->vehiculoIdModelo;
        $vehiculo->save();

        return redirect()->route('vehiculos.index')->with('success', Lang::get('alerts.vehiculos_updated_successfully'));
    }
    
    public function delete(Request $request, Vehiculo $vehiculo) {
        if($vehiculo != null) {
            $vehiculo->delete();
            return redirect()->route('vehiculos.index')->with('success', Lang::get('alerts.vehiculos_deleted_successfully'));
        }
        return redirect()->route('vehiculos.index')->with('error', Lang::get('alerts.vehiculos_deleted_error'));
    }

    public function validateVehiculo($request) {
        return Validator::make($request->all(), [
            'vehiculoMatricula' => ['required', 'string', 'max:8'],
            'vehiculoFechaMatricula' => ['required', 'date_format:d-m-Y'],
            'vehiculoColor' => ['required', 'string', 'max:10'],
            'vehiculoPrecio' => ['required', 'integer'],
            'vehiculoKilometraje' => ['required', 'integer'],
            'vehiculoAntecedentes' => ['required', 'string', 'max:50'],
            'vehiculoIdModelo' => ['required', 'exists:modelos,idModelo'],
        ]);
    }
 }
 