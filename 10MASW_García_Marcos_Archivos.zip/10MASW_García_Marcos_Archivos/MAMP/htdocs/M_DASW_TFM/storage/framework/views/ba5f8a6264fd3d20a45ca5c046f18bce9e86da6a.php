<?php $__env->startSection('title'); ?>
    <?php if(isset($lugar)): ?>
        <?php echo e(__('strings.lugar_edit_title')); ?>

    <?php else: ?>
        <?php echo e(__('strings.lugar_create_title')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <?php if(isset($lugar)): ?>
                        <h1><?php echo e(__('strings.lugar_edit_title')); ?> <?php echo e($lugar->residencia); ?> <?php echo e($lugar->distritoPostal); ?></h1>
                    <?php else: ?>
                        <h1><?php echo e(__('strings.lugar_create_title')); ?></h1>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if(isset($lugar)): ?>
                    <form name="edit_lugar" action="<?php echo e(route('lugars.update', $lugar)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php else: ?>
                    <form name="create_lugar" action="<?php echo e(route('lugars.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php endif; ?>
                    <div class="mb-3">
                        <label for="lugarResidencia" class="form-label"> <?php echo e(__('strings.residencia_header')); ?></label>
                        <input id="lugarResidencia" name="lugarResidencia" type="text" placeholder="<?php echo e(__('strings.residencia_placeholder')); ?>"
                        class="form-control" required <?php if(isset($lugar)): ?> value="<?php echo e(old('lugarResidencia', $lugar->residencia)); ?>" <?php else: ?> value="<?php echo e(old('lugarResidencia')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="lugarDistritoPostal" class="form-label"> <?php echo e(__('strings.distritoPostal_header')); ?></label>
                        <input id="lugarDistritoPostal" name="lugarDistritoPostal" type="text" placeholder="<?php echo e(__('strings.distritoPostal_placeholder')); ?>"
                        class="form-control" required <?php if(isset($lugar)): ?> value="<?php echo e(old('lugarDistritoPostal', $lugar->distritoPostal)); ?>" <?php else: ?> value="<?php echo e(old('lugarDistritoPostal')); ?>" <?php endif; ?> />
                    </div>
                    <input type="submit" value="<?php if(isset($lugar)): ?> <?php echo e(__('strings.save_btn')); ?> <?php else: ?> <?php echo e(__('strings.create_btn')); ?> <?php endif; ?>" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/lugars/create.blade.php ENDPATH**/ ?>