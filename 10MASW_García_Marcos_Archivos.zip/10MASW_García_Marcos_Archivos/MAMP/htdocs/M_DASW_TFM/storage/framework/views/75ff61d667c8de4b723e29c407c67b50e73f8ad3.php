<?php $__env->startSection('title'); ?>
    <?php if(isset($compra)): ?>
        <?php echo e(__('strings.compra_edit_title')); ?>

    <?php else: ?>
        <?php echo e(__('strings.compra_create_title')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <?php if(isset($compra)): ?>
                        <h1><?php echo e(__('strings.compra_edit_title')); ?> <?php echo e($compra->DNI); ?> <?php echo e($compra->idPoliza); ?></h1> 
                    <?php else: ?>
                        <h1><?php echo e(__('strings.compra_create_title')); ?></h1>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if(isset($compra)): ?>
                    <form name="edit_compra" action="<?php echo e(route('compras.update', $compra)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php else: ?>
                    <form name="create_compra" action="<?php echo e(route('compras.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php endif; ?>
                    <div class="mb-3">
                        <label for="compraDNI" class="form-label"><?php echo e(__('strings.DNI_header')); ?></label>
                        <select id="compraDNI" name="compraDNI" class="form-select">                            
                            <?php if(isset($compra)): ?>
                                <option value="-1" selected><?php echo e(__('strings.search_DNI_placeholder')); ?></option>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($compra->DNI == $cliente->DNI): ?>     
                                        <option value="<?php echo e($cliente->DNI); ?>" selected><?php echo e($cliente->DNI); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($cliente->DNI); ?>"><?php echo e($cliente->DNI); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="-1" selected><?php echo e(__('strings.DNI_placeholder')); ?></option>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cliente->DNI); ?>"><?php echo e($cliente->DNI); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="compraIdPoliza" class="form-label"><?php echo e(__('strings.idPoliza_header')); ?></label>
                        <select id="compraIdPoliza" name="compraIdPoliza" class="form-select">                            
                            <?php if(isset($compra)): ?>
                                <option value="-1" selected><?php echo e(__('strings.search_idPoliza_placeholder')); ?></option>
                                <?php $__currentLoopData = $polizas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poliza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($compra->idPoliza == $poliza->idPoliza): ?>     
                                        <option value="<?php echo e($poliza->idPoliza); ?>" selected><?php echo e($poliza->idPoliza); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($poliza->idPoliza); ?>"><?php echo e($poliza->idPoliza); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="-1" selected><?php echo e(__('strings.idPoliza_placeholder')); ?></option>
                                <?php $__currentLoopData = $polizas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poliza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($poliza->idPoliza); ?>"><?php echo e($poliza->idPoliza); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <input type="submit" value="<?php if(isset($compra)): ?> <?php echo e(__('strings.save_btn')); ?> <?php else: ?> <?php echo e(__('strings.create_btn')); ?> <?php endif; ?>" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/compras/create.blade.php ENDPATH**/ ?>