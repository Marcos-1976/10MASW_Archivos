<?php $__env->startSection('title'); ?>
    <?php if(isset($asegura)): ?>
        <?php echo e(__('strings.asegura_edit_title')); ?>

    <?php else: ?>
        <?php echo e(__('strings.asegura_create_title')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <?php if(isset($asegura)): ?>
                        <h1><?php echo e(__('strings.asegura_edit_title')); ?> <?php echo e($asegura->DNI); ?> <?php echo e($asegura->matricula); ?></h1> 
                    <?php else: ?>
                        <h1><?php echo e(__('strings.asegura_create_title')); ?></h1>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if(isset($asegura)): ?>
                    <form name="edit_asegura" action="<?php echo e(route('aseguras.update', $asegura)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php else: ?>
                    <form name="create_asegura" action="<?php echo e(route('aseguras.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php endif; ?>
                    <div class="mb-3">
                        <label for="aseguraDNI" class="form-label"><?php echo e(__('strings.DNI_header')); ?></label>
                        <select id="aseguraDNI" name="aseguraDNI" class="form-select">                            
                            <?php if(isset($asegura)): ?>
                                <option value="-1" selected><?php echo e(__('strings.search_DNI_placeholder')); ?></option>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($asegura->DNI == $cliente->DNI): ?>     
                                        <option value="<?php echo e($cliente->DNI); ?>" selected><?php echo e($cliente->DNI); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($cliente->DNI); ?>"><?php echo e($cliente->DNI); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="-1" selected><?php echo e(__('strings.DNI_placeholder')); ?></option>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cliente->DNI); ?>"><?php echo e($cliente->DNI); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="aseguraMatricula" class="form-label"><?php echo e(__('strings.matricula_header')); ?></label>
                        <select id="aseguraMatricula" name="aseguraMatricula" class="form-select">                            
                            <?php if(isset($asegura)): ?>
                                <option value="-1" selected><?php echo e(__('strings.search_matricula_placeholder')); ?></option>
                                <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($asegura->matricula == $vehiculo->matricula): ?>     
                                        <option value="<?php echo e($vehiculo->matricula); ?>" selected><?php echo e($vehiculo->matricula); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($vehiculo->matricula); ?>"><?php echo e($vehiculo->matricula); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="-1" selected><?php echo e(__('strings.matricula_placeholder')); ?></option>
                                <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vehiculo->matricula); ?>"><?php echo e($vehiculo->matricula); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <input type="submit" value="<?php if(isset($asegura)): ?> <?php echo e(__('strings.save_btn')); ?> <?php else: ?> <?php echo e(__('strings.create_btn')); ?> <?php endif; ?>" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/aseguras/create.blade.php ENDPATH**/ ?>