<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    </head>

    <body>
        <div class="flex-center position-ref full-height">
            <div id="app", class="content">
                <?php if(Auth::check()): ?>
                <div class="float-right">
                    <a class="my-2 mx-2 btn btn-danger" href="<?php echo e(route('logout')); ?>">Salir</a>
                    <a class="btn btn-secondary" href="<?php echo e(route('welcome')); ?>">INICIO</a>
                </div>
                <?php endif; ?>

                <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </body>

</html><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/layouts/main.blade.php ENDPATH**/ ?>