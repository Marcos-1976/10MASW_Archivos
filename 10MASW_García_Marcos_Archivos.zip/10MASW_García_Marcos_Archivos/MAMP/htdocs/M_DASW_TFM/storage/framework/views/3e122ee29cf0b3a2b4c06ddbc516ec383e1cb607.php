<?php $__env->startSection('title'); ?>
    <?php if(isset($poliza)): ?>
        <?php echo e(__('strings.poliza_edit_title')); ?>

    <?php else: ?>
        <?php echo e(__('strings.poliza_create_title')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <?php if(isset($poliza)): ?>
                        <h1><?php echo e(__('strings.poliza_edit_title')); ?> <?php echo e($poliza->poliza); ?> <?php echo e($poliza->prima); ?> <?php echo e($poliza->fechaAlta); ?> <?php echo e($poliza->fechaVencimiento); ?> <?php echo e($poliza->tipoPoliza); ?></h1>
                    <?php else: ?>
                        <h1><?php echo e(__('strings.poliza_create_title')); ?></h1>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if(isset($poliza)): ?>
                    <form name="edit_poliza" action="<?php echo e(route('polizas.update', $poliza)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php else: ?>
                    <form name="create_poliza" action="<?php echo e(route('polizas.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php endif; ?>
                    <div class="mb-3">
                        <label for="polizaPrima" class="form-label"> <?php echo e(__('strings.prima_header')); ?></label>
                        <input id="polizaPrima" name="polizaPrima" type="text" placeholder="<?php echo e(__('strings.prima_placeholder')); ?>"
                        class="form-control" required <?php if(isset($poliza)): ?> value="<?php echo e(old('polizaPrima', $poliza->prima)); ?>" <?php else: ?> value="<?php echo e(old('polizaPrima')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="polizaPrima" class="form-label"> <?php echo e(__('strings.prima_header')); ?></label>
                        <input id="polizaPrima" name="polizaPrima" type="text" placeholder="<?php echo e(__('strings.prima_placeholder')); ?>"
                        class="form-control" required <?php if(isset($poliza)): ?> value="<?php echo e(old('polizaPrima', $poliza->prima)); ?>" <?php else: ?> value="<?php echo e(old('polizaPrima')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="polizaFechaAlta" class="form-label"> <?php echo e(__('strings.fechaAlta_header')); ?></label>
                        <input id="polizaFechaAlta" name="polizaFechaAlta" type="text" placeholder="<?php echo e(__('strings.fechaAlta_placeholder')); ?>"
                        class="form-control" required <?php if(isset($poliza)): ?> value="<?php echo e(old('polizaFechaAlta', $poliza->fechaAlta)); ?>" <?php else: ?> value="<?php echo e(old('polizaFechaAlta')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="polizaFechaVencimiento" class="form-label"> <?php echo e(__('strings.fechaVencimiento_header')); ?></label>
                        <input id="polizaFechaVencimiento" name="polizaFechaVencimiento" type="text" placeholder="<?php echo e(__('strings.fechaVencimiento_placeholder')); ?>"
                        class="form-control" required <?php if(isset($poliza)): ?> value="<?php echo e(old('polizaFechaVencimiento', $poliza->fechaVencimiento)); ?>" <?php else: ?> value="<?php echo e(old('polizaFechaVencimiento')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="polizaTipo" class="form-label"> <?php echo e(__('strings.tipoPoliza_header')); ?></label>
                        <input id="polizaTipo" name="polizaTipo" type="text" placeholder="<?php echo e(__('strings.tipoPoliza_placeholder')); ?>"
                        class="form-control" required <?php if(isset($poliza)): ?> value="<?php echo e(old('polizaTipo', $poliza->tipoPoliza)); ?>" <?php else: ?> value="<?php echo e(old('polizaTipo')); ?>" <?php endif; ?> />
                    </div>
                    <input type="submit" value="<?php if(isset($poliza)): ?> <?php echo e(__('strings.save_btn')); ?> <?php else: ?> <?php echo e(__('strings.create_btn')); ?> <?php endif; ?>" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/polizas/create.blade.php ENDPATH**/ ?>