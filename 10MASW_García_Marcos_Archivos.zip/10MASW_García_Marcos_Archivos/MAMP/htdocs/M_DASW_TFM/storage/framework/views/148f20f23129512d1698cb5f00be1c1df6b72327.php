<?php $__env->startSection('title'); ?>
    <?php echo e(__('strings.compra_index_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1><?php echo e(__('strings.compra_index_title')); ?></h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="<?php echo e(route('compras.create')); ?>"><?php echo e(__('strings.compra_create_btn')); ?>&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="compraDNI" class="form-label"><?php echo e(__('strings.DNI_header')); ?></label>
                        <select id="compraDNI" name="compraDNI" class="form-select">
                            <option value="-1" selected><?php echo e(__('strings.search_DNI_placeholder')); ?></option>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($compraDNI == $cliente->DNI): ?> 
                                    <option value="<?php echo e($cliente->DNI); ?>" selected><?php echo e($cliente->DNI); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($cliente->DNI); ?>"><?php echo e($cliente->DNI); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        <label for="compraIdPoliza" class="form-label"><?php echo e(__('strings.idPoliza_header')); ?></label>
                        <select id="compraIdPoliza" name="compraIdPoliza" class="form-select">
                            <option value="-1" selected><?php echo e(__('strings.search_idPoliza_placeholder')); ?></option>
                            <?php $__currentLoopData = $polizas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poliza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($compraIdPoliza == $poliza->idPoliza): ?>
                                    <option value="<?php echo e($poliza->idPoliza); ?>" selected><?php echo e($poliza->idPoliza); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($poliza->idPoliza); ?>"><?php echo e($poliza->idPoliza); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        <button type="submit" class="btn btn-primary my-2"><?php echo e(__('strings.search_btn')); ?></button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    <?php if(count($compras) > 0): ?>
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th><?php echo e(__('strings.DNI_header')); ?></th>
                                <th><?php echo e(__('strings.idPoliza_header')); ?></th>
                                <th><?php echo e(__('strings.actions_header')); ?></th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($compra->cliente->DNI.' - Nombre: '.$compra->cliente->nombre); ?></td> 
                                    <td><?php echo e($compra->poliza->idPoliza); ?></td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Compra">
                                            <a class="btn btn-success" href="<?php echo e(route('compras.edit', $compra)); ?>"><?php echo e(__('strings.edit_btn')); ?></a>&nbsp;&nbsp;
                                            <form name="delete-form-<?php echo e($compra->DNI); ?>" action="<?php echo e(route('compras.delete', $compra)); ?>" method="post" style="display: inline-block;"> 
                                                <?php echo e(method_field('delete')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger"><?php echo e(__('strings.delete_btn')); ?></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-warning mt-3">
                            <?php echo e(__('strings.no_compras')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                <?php echo e($compras->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/compras/index.blade.php ENDPATH**/ ?>