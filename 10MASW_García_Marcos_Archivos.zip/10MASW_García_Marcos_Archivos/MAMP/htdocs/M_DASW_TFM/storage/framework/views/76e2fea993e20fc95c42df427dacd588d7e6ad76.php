<?php $__env->startSection('title'); ?>
    <?php echo e(__('strings.hatenido_index_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1><?php echo e(__('strings.hatenido_index_title')); ?></h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="<?php echo e(route('hatenidos.create')); ?>"><?php echo e(__('strings.hatenido_create_btn')); ?>&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="hatenidoMatricula" class="form-label"><?php echo e(__('strings.matricula_header')); ?></label>
                        <select id="hatenidoMatricula" name="hatenidoMatricula" class="form-select">
                            <option value="-1" selected><?php echo e(__('strings.search_matricula_placeholder')); ?></option>
                            <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($hatenidoMatricula == $vehiculo->matricula): ?> 
                                    <option value="<?php echo e($vehiculo->matricula); ?>" selected><?php echo e($vehiculo->matricula); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($vehiculo->matricula); ?>"><?php echo e($vehiculo->matricula); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        <label for="hatenidoIdAccidente" class="form-label"><?php echo e(__('strings.idAccidente_header')); ?></label>
                        <select id="hatenidoIdAccidente" name="hatenidoIdAccidente" class="form-select">
                            <option value="-1" selected><?php echo e(__('strings.search_idAccidente_placeholder')); ?></option>
                            <?php $__currentLoopData = $accidentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accidente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($hatenidoIdAccidente == $accidente->idAccidente): ?>
                                    <option value="<?php echo e($accidente->idAccidente); ?>" selected><?php echo e($accidente->idAccidente); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($accidente->idAccidente); ?>"><?php echo e($accidente->idAccidente); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        <button type="submit" class="btn btn-primary my-2"><?php echo e(__('strings.search_btn')); ?></button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    <?php if(count($hatenidos) > 0): ?>
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th><?php echo e(__('strings.matricula_header')); ?></th>
                                <th><?php echo e(__('strings.idAccidente_header')); ?></th>
                                <th><?php echo e(__('strings.actions_header')); ?></th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $hatenidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hatenido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($hatenido->vehiculo->matricula); ?></td> 
                                    <td><?php echo e($hatenido->accidente->idAccidente); ?></td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Hatenido">
                                            <a class="btn btn-success" href="<?php echo e(route('hatenidos.edit', $hatenido)); ?>"><?php echo e(__('strings.edit_btn')); ?></a>&nbsp;&nbsp;
                                            <form name="delete-form-<?php echo e($hatenido->matricula); ?>" action="<?php echo e(route('hatenidos.delete', $hatenido)); ?>" method="post" style="display: inline-block;"> 
                                                <?php echo e(method_field('delete')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger"><?php echo e(__('strings.delete_btn')); ?></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-warning mt-3">
                            <?php echo e(__('strings.no_hatenidos')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                <?php echo e($hatenidos->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/hatenidos/index.blade.php ENDPATH**/ ?>