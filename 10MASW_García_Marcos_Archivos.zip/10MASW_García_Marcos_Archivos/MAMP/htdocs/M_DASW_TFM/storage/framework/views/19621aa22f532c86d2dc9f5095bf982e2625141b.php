<?php
use App\ErrorSession;
?>
<?php if(Session::has(ErrorSession::SUCCESS_COD)): ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <strong><?php echo e(__('alerts.successful_message')); ?></strong> <?php echo e(Session::get(ErrorSession::SUCCESS_COD)); ?>

                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if(Session::has(ErrorSession::INFO_COD)): ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="alert alert-info alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <strong><?php echo e(__('alerts.info_message')); ?></strong> <?php echo e(Session::get(ErrorSession::INFO_COD)); ?>

                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if(Session::has(ErrorSession::WARNING_COD)): ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="alert alert-warning alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <strong><?php echo e(__('alerts.warning_message')); ?></strong> <?php echo e(Session::get(ErrorSession::WARNING_COD)); ?>

                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if(Session::has(ErrorSession::ERROR_COD)): ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <strong><?php echo e(__('alerts.error_message')); ?></strong> <?php echo e(Session::get(ErrorSession::ERROR_COD)); ?>

                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php if($errors->any()): ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <strong><?php echo e(__('alerts.error_message')); ?></strong>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/partials/alerts.blade.php ENDPATH**/ ?>