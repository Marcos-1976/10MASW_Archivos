<?php echo e($slot); ?>

<?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>