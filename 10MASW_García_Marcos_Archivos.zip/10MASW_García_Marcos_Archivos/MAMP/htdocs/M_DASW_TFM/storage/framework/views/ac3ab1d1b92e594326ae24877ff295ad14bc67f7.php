<?php $__env->startSection('title'); ?>
    <?php echo e(__('strings.poliza_index_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1><?php echo e(__('strings.poliza_index_title')); ?></h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="<?php echo e(route('polizas.create')); ?>"><?php echo e(__('strings.poliza_create_btn')); ?>&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="polizaIdPoliza" class="form-label"><?php echo e(__('strings.idPoliza_header')); ?></label>
                        <input id="polizaIdPoliza" name="polizaIdPoliza" class="form-control" value="<?php if(isset($polizaIdPoliza)): ?> <?php echo e($polizaIdPoliza); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_idPoliza_placeholder')); ?>" />
                        
                        <label for="polizaPrima" class="form-label"><?php echo e(__('strings.prima_header')); ?></label>
                        <input id="polizaPrima" name="polizaPrima" class="form-control" value="<?php if(isset($polizaPrima)): ?> <?php echo e($polizaPrima); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_prima_placeholder')); ?>" />

                        <label for="polizaFechaAlta" class="form-label"><?php echo e(__('strings.fechaAlta_header')); ?></label>
                        <input id="polizaFechaAlta" name="polizaFechaAlta" class="form-control" value="<?php if(isset($polizaFechaAlta)): ?> <?php echo e($polizaFechaAlta); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_fechaAlta_placeholder')); ?>" />
                        
                        <label for="polizaFechaVencimiento" class="form-label"><?php echo e(__('strings.fechaVencimiento_header')); ?></label>
                        <input id="polizaFechaVencimiento" name="polizaFechaVencimiento" class="form-control" value="<?php if(isset($polizaFechaVencimiento)): ?> <?php echo e($polizaFechaVencimiento); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_fechaVencimiento_placeholder')); ?>" />
                        
                        <label for="polizaTipo" class="form-label"><?php echo e(__('strings.tipoPoliza_header')); ?></label>
                        <input id="polizaTipo" name="polizaTipo" class="form-control" value="<?php if(isset($polizaTipo)): ?> <?php echo e($polizaTipo); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_tipoPoliza_placeholder')); ?>" />
                        
                        <button type="submit" class="btn btn-primary my-2"><?php echo e(__('strings.search_btn')); ?></button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    <?php if(count($polizas) > 0): ?>
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th><?php echo e(__('strings.idPoliza_header')); ?></th>
                                <th><?php echo e(__('strings.prima_header')); ?></th>
                                <th><?php echo e(__('strings.fechaAlta_header')); ?></th>
                                <th><?php echo e(__('strings.fechaVencimiento_header')); ?></th>
                                <th><?php echo e(__('strings.tipoPoliza_header')); ?></th>
                                <th><?php echo e(__('strings.actions_header')); ?></th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $polizas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poliza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($poliza->idPoliza); ?></td>
                                    <td><?php echo e($poliza->prima); ?></td>
                                    <td><?php echo e($poliza->fechaAlta); ?></td>
                                    <td><?php echo e($poliza->fechaVencimiento); ?></td>
                                    <td><?php echo e($poliza->tipoPoliza); ?></td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Poliza">
                                            <a class="btn btn-success" href="<?php echo e(route('polizas.edit', $poliza)); ?>"><?php echo e(__('strings.edit_btn')); ?></a>&nbsp;&nbsp;
                                            <form name="delete-form-<?php echo e($poliza->idPoliza); ?>" action="<?php echo e(route('polizas.delete', $poliza)); ?>" method="post" style="display: inline-block;">
                                                <?php echo e(method_field('delete')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger"><?php echo e(__('strings.delete_btn')); ?></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-warning mt-3">
                            <?php echo e(__('strings.no_polizas')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                <?php echo e($polizas->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/polizas/index.blade.php ENDPATH**/ ?>