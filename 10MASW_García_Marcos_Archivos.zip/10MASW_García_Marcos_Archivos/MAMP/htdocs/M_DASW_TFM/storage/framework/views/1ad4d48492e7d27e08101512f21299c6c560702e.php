<?php $__env->startSection('title'); ?>
    <?php if(isset($vehiculo)): ?>
        <?php echo e(__('strings.vehiculo_edit_title')); ?>

    <?php else: ?>
        <?php echo e(__('strings.vehiculo_create_title')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <?php if(isset($vehiculo)): ?>
                        <h1><?php echo e(__('strings.vehiculo_edit_title')); ?> <?php echo e($vehiculo->matricula); ?> <?php echo e($vehiculo->fechaMatricula); ?> <?php echo e($vehiculo->color); ?> <?php echo e($vehiculo->precio); ?> <?php echo e($vehiculo->kilometraje); ?> <?php echo e($vehiculo->antecedentes); ?> <?php echo e($vehiculo->idModelo); ?></h1>
                    <?php else: ?>
                        <h1><?php echo e(__('strings.vehiculo_create_title')); ?></h1>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if(isset($vehiculo)): ?>
                    <form name="edit_vehiculo" action="<?php echo e(route('vehiculos.update', $vehiculo)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php else: ?>
                    <form name="create_vehiculo" action="<?php echo e(route('vehiculos.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php endif; ?>
                    <div class="mb-3">
                        <label for="vehiculoMatricula" class="form-label"> <?php echo e(__('strings.matricula_header')); ?></label>
                        <input id="vehiculoMatricula" name="vehiculoMatricula" type="text" placeholder="<?php echo e(__('strings.matricula_placeholder')); ?>"
                        class="form-control" required <?php if(isset($vehiculo)): ?> value="<?php echo e(old('vehiculoMatricula', $vehiculo->matricula)); ?>" <?php else: ?> value="<?php echo e(old('vehiculoMatricula')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="vehiculoFechaMatricula" class="form-label"> <?php echo e(__('strings.fechaMatricula_header')); ?></label>
                        <input id="vehiculoFechaMatricula" name="vehiculoFechaMatricula" type="text" placeholder="<?php echo e(__('strings.fechaMatricula_placeholder')); ?>"
                        class="form-control" required <?php if(isset($vehiculo)): ?> value="<?php echo e(old('vehiculoFechaMatricula', $vehiculo->fechaMatricula)); ?>" <?php else: ?> value="<?php echo e(old('vehiculoFechaMatricula')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="vehiculoColor" class="form-label"> <?php echo e(__('strings.color_header')); ?></label>
                        <input id="vehiculoColor" name="vehiculoColor" type="text" placeholder="<?php echo e(__('strings.color_placeholder')); ?>"
                        class="form-control" required <?php if(isset($vehiculo)): ?> value="<?php echo e(old('vehiculoColor', $vehiculo->color)); ?>" <?php else: ?> value="<?php echo e(old('vehiculoColor')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="vehiculoPrecio" class="form-label"> <?php echo e(__('strings.precio_header')); ?></label>
                        <input id="vehiculoPrecio" name="vehiculoPrecio" type="text" placeholder="<?php echo e(__('strings.precio_placeholder')); ?>"
                        class="form-control" required <?php if(isset($vehiculo)): ?> value="<?php echo e(old('vehiculoPrecio', $vehiculo->precio)); ?>" <?php else: ?> value="<?php echo e(old('vehiculoPrecio')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="vehiculoKilometraje" class="form-label"> <?php echo e(__('strings.kilometraje_header')); ?></label>
                        <input id="vehiculoKilometraje" name="vehiculoKilometraje" type="text" placeholder="<?php echo e(__('strings.kilometraje_placeholder')); ?>"
                        class="form-control" required <?php if(isset($vehiculo)): ?> value="<?php echo e(old('vehiculoKilometraje', $vehiculo->kilometraje)); ?>" <?php else: ?> value="<?php echo e(old('vehiculoKilometraje')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="vehiculoAntecedentes" class="form-label"> <?php echo e(__('strings.antecedentes_header')); ?></label>
                        <input id="vehiculoAntecedentes" name="vehiculoAntecedentes" type="text" placeholder="<?php echo e(__('strings.antecedentes_placeholder')); ?>"
                        class="form-control" required <?php if(isset($vehiculo)): ?> value="<?php echo e(old('vehiculoAntecedentes', $vehiculo->antecedentes)); ?>" <?php else: ?> value="<?php echo e(old('vehiculoAntecedentes')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="vehiculoIdModelo" class="form-label"><?php echo e(__('strings.idModelo_header')); ?></label>
                        <select id="vehiculoIdModelo" name="vehiculoIdModelo" class="form-select">                            
                            <?php if(isset($vehiculo)): ?>
                                <option value="-1" selected><?php echo e(__('strings.search_idModelo_placeholder')); ?></option>
                                <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($vehiculo->idModelo == $modelo->idModelo): ?>     
                                        <option value="<?php echo e($modelo->idModelo); ?>" selected><?php echo e($modelo->idModelo); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($modelo->idModelo); ?>"><?php echo e($modelo->idModelo); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="-1" selected><?php echo e(__('strings.idModelo_placeholder')); ?></option>
                                <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($modelo->idModelo); ?>"><?php echo e($modelo->idModelo); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <input type="submit" value="<?php if(isset($vehiculo)): ?> <?php echo e(__('strings.save_btn')); ?> <?php else: ?> <?php echo e(__('strings.create_btn')); ?> <?php endif; ?>" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/vehiculos/create.blade.php ENDPATH**/ ?>