<?php $__env->startSection('title'); ?>
    <?php echo e(__('strings.modelo_index_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1><?php echo e(__('strings.modelo_index_title')); ?></h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="<?php echo e(route('modelos.create')); ?>"><?php echo e(__('strings.modelo_create_btn')); ?>&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="modeloIdModelo" class="form-label"><?php echo e(__('strings.idModelo_header')); ?></label>
                        <input id="modeloIdModelo" name="modeloIdModelo" class="form-control" value="<?php if(isset($modeloIdModelo)): ?> <?php echo e($modeloIdModelo); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_idModelo_placeholder')); ?>" />
                        
                        <label for="modeloTipoCarroceria" class="form-label"><?php echo e(__('strings.tipoCarroceria_header')); ?></label>
                        <input id="modeloTipoCarroceria" name="modeloTipoCarroceria" class="form-control" value="<?php if(isset($modeloTipoCarroceria)): ?> <?php echo e($modeloTipoCarroceria); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_tipoCarroceria_placeholder')); ?>" />

                        <label for="modeloFabricante" class="form-label"><?php echo e(__('strings.fabricante_header')); ?></label>
                        <input id="modeloFabricante" name="modeloFabricante" class="form-control" value="<?php if(isset($modeloFabricante)): ?> <?php echo e($modeloFabricante); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_fabricante_placeholder')); ?>" />

                        <label for="modeloPotencia" class="form-label"><?php echo e(__('strings.potencia_header')); ?></label>
                        <input id="modeloPotencia" name="modeloPotencia" class="form-control" value="<?php if(isset($modeloPotencia)): ?> <?php echo e($modeloPotencia); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_potencia_placeholder')); ?>" />

                        <button type="submit" class="btn btn-primary my-2"><?php echo e(__('strings.search_btn')); ?></button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    <?php if(count($modelos) > 0): ?>
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th><?php echo e(__('strings.idModelo_header')); ?></th>
                                <th><?php echo e(__('strings.tipoCarroceria_header')); ?></th>
                                <th><?php echo e(__('strings.fabricante_header')); ?></th>
                                <th><?php echo e(__('strings.potencia_header')); ?></th>
                                <th><?php echo e(__('strings.actions_header')); ?></th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($modelo->idModelo); ?></td>
                                    <td><?php echo e($modelo->tipoCarroceria); ?></td>
                                    <td><?php echo e($modelo->fabricante); ?></td>
                                    <td><?php echo e($modelo->potencia); ?></td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Poliza">
                                            <a class="btn btn-success" href="<?php echo e(route('modelos.edit', $modelo)); ?>"><?php echo e(__('strings.edit_btn')); ?></a>&nbsp;&nbsp;
                                            <form name="delete-form-<?php echo e($modelo->idModelo); ?>" action="<?php echo e(route('modelos.delete', $modelo)); ?>" method="post" style="display: inline-block;">
                                                <?php echo e(method_field('delete')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger"><?php echo e(__('strings.delete_btn')); ?></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-warning mt-3">
                            <?php echo e(__('strings.no_modelos')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                <?php echo e($modelos->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/modelos/index.blade.php ENDPATH**/ ?>