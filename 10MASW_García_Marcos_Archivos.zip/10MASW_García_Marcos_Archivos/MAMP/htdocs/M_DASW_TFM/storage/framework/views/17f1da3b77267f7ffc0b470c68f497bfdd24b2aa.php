<?php $__env->startSection('title'); ?>
    <?php echo e(__('strings.asegura_index_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1><?php echo e(__('strings.asegura_index_title')); ?></h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="<?php echo e(route('aseguras.create')); ?>"><?php echo e(__('strings.asegura_create_btn')); ?>&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="aseguraDNI" class="form-label"><?php echo e(__('strings.DNI_header')); ?></label>
                        <select id="aseguraDNI" name="aseguraDNI" class="form-select">
                            <option value="-1" selected><?php echo e(__('strings.search_DNI_placeholder')); ?></option>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($aseguraDNI == $cliente->DNI): ?> 
                                    <option value="<?php echo e($cliente->DNI); ?>" selected><?php echo e($cliente->DNI); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($cliente->DNI); ?>"><?php echo e($cliente->DNI); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        <label for="aseguraMatricula" class="form-label"><?php echo e(__('strings.matricula_header')); ?></label>
                        <select id="aseguraMatricula" name="aseguraMatricula" class="form-select">
                            <option value="-1" selected><?php echo e(__('strings.search_matricula_placeholder')); ?></option>
                            <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($aseguraMatricula == $vehiculo->matricula): ?>
                                    <option value="<?php echo e($vehiculo->matricula); ?>" selected><?php echo e($vehiculo->matricula); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($vehiculo->matricula); ?>"><?php echo e($vehiculo->matricula); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        <button type="submit" class="btn btn-primary my-2"><?php echo e(__('strings.search_btn')); ?></button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    <?php if(count($aseguras) > 0): ?>
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th><?php echo e(__('strings.DNI_header')); ?></th>
                                <th><?php echo e(__('strings.matricula_header')); ?></th>
                                <th><?php echo e(__('strings.actions_header')); ?></th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $aseguras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asegura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($asegura->cliente->DNI.' - Nombre: '.$asegura->cliente->nombre); ?></td> 
                                    <td><?php echo e($asegura->vehiculo->matricula); ?></td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Asegura">
                                            <a class="btn btn-success" href="<?php echo e(route('aseguras.edit', $asegura)); ?>"><?php echo e(__('strings.edit_btn')); ?></a>&nbsp;&nbsp;
                                            <form name="delete-form-<?php echo e($asegura->DNI); ?>" action="<?php echo e(route('aseguras.delete', $asegura)); ?>" method="post" style="display: inline-block;"> 
                                                <?php echo e(method_field('delete')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger"><?php echo e(__('strings.delete_btn')); ?></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-warning mt-3">
                            <?php echo e(__('strings.no_aseguras')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                <?php echo e($aseguras->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/aseguras/index.blade.php ENDPATH**/ ?>