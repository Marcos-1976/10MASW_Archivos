<?php $__env->startSection('title'); ?>
    <?php if(isset($accidente)): ?>
        <?php echo e(__('strings.accidente_edit_title')); ?>

    <?php else: ?>
        <?php echo e(__('strings.accidente_create_title')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <?php if(isset($accidente)): ?>
                        <h1><?php echo e(__('strings.accidente_edit_title')); ?> <?php echo e($accidente->accidente); ?> <?php echo e($accidente->fechaAccidente); ?> <?php echo e($accidente->lugarAccidente); ?> <?php echo e($accidente->porcentajeDanio); ?> <?php echo e($accidente->coberturaSiniestro); ?></h1>
                    <?php else: ?>
                        <h1><?php echo e(__('strings.accidente_create_title')); ?></h1>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if(isset($accidente)): ?>
                    <form name="edit_accidente" action="<?php echo e(route('accidentes.update', $accidente)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php else: ?>
                    <form name="create_accidente" action="<?php echo e(route('accidentes.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php endif; ?>
                    <div class="mb-3">
                        <label for="accidenteFechaccidente" class="form-label"> <?php echo e(__('strings.fechaAccidente_header')); ?></label>
                        <input id="accidenteFechaAccidente" name="accidenteFechaAccidente" type="text" placeholder="<?php echo e(__('strings.fechaAccidente_placeholder')); ?>"
                        class="form-control" required <?php if(isset($accidente)): ?> value="<?php echo e(old('accidenteFechaAccidente', $accidente->fechaAccidente)); ?>" <?php else: ?> value="<?php echo e(old('accidenteFechaAccidente')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="accidenteLugarAccidente" class="form-label"> <?php echo e(__('strings.lugarAccidente_header')); ?></label>
                        <input id="accidenteLugarAccidente" name="accidenteLugarAccidente" type="text" placeholder="<?php echo e(__('strings.lugarAccidente_placeholder')); ?>"
                        class="form-control" required <?php if(isset($accidente)): ?> value="<?php echo e(old('accidenteLugarAccidente', $accidente->lugarAccidente)); ?>" <?php else: ?> value="<?php echo e(old('accidenteLugarAccidente')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="accidentePorcentajeDanio" class="form-label"> <?php echo e(__('strings.porcentajeDanio_header')); ?></label>
                        <input id="accidentePorcentajeDanio" name="accidentePorcentajeDanio" type="text" placeholder="<?php echo e(__('strings.porcentajeDanio_placeholder')); ?>"
                        class="form-control" required <?php if(isset($accidente)): ?> value="<?php echo e(old('accidentePorcentajeDanio', $accidente->porcentajeDanio)); ?>" <?php else: ?> value="<?php echo e(old('accidentePorcentajeDanio')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="accidenteCoberturaSiniestro" class="form-label"> <?php echo e(__('strings.coberturaSiniestro_header')); ?></label>
                        <input id="accidenteCoberturaSiniestro" name="accidenteCoberturaSiniestro" type="text" placeholder="<?php echo e(__('strings.coberturaSiniestro_placeholder')); ?>"
                        class="form-control" required <?php if(isset($accidente)): ?> value="<?php echo e(old('accidenteCoberturaSiniestro', $accidente->coberturaSiniestro)); ?>" <?php else: ?> value="<?php echo e(old('accidenteCoberturaSiniestro')); ?>" <?php endif; ?> />
                    </div>
                    <input type="submit" value="<?php if(isset($accidente)): ?> <?php echo e(__('strings.save_btn')); ?> <?php else: ?> <?php echo e(__('strings.create_btn')); ?> <?php endif; ?>" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/accidentes/create.blade.php ENDPATH**/ ?>