<?php $__env->startSection('title'); ?>
    <?php if(isset($modelo)): ?>
        <?php echo e(__('strings.modelo_edit_title')); ?>

    <?php else: ?>
        <?php echo e(__('strings.modelo_create_title')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <?php if(isset($modelo)): ?>
                        <h1><?php echo e(__('strings.modelo_edit_title')); ?> <?php echo e($modelo->idModelo); ?> <?php echo e($modelo->tipoCarroceria); ?> <?php echo e($modelo->fabricante); ?> <?php echo e($modelo->potencia); ?></h1>
                    <?php else: ?>
                        <h1><?php echo e(__('strings.modelo_create_title')); ?></h1>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if(isset($modelo)): ?>
                    <form name="edit_modelo" action="<?php echo e(route('modelos.update', $modelo)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php else: ?>
                    <form name="create_modelo" action="<?php echo e(route('modelos.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php endif; ?>
                    <div class="mb-3">
                        <label for="modeloIdModelo" class="form-label"> <?php echo e(__('strings.idModelo_header')); ?></label>
                        <input id="modeloIdModelo" name="modeloIdModelo" type="text" placeholder="<?php echo e(__('strings.idModelo_placeholder')); ?>"
                        class="form-control" required <?php if(isset($modelo)): ?> value="<?php echo e(old('modeloIdModelo', $modelo->idModelo)); ?>" <?php else: ?> value="<?php echo e(old('modeloIdModelo')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="modeloTipoCarroceria" class="form-label"> <?php echo e(__('strings.tipoCarroceria_header')); ?></label>
                        <input id="modeloTipoCarroceria" name="modeloTipoCarroceria" type="text" placeholder="<?php echo e(__('strings.tipoCarroceria_placeholder')); ?>"
                        class="form-control" required <?php if(isset($modelo)): ?> value="<?php echo e(old('modeloTipoCarroceria', $modelo->tipoCarroceria)); ?>" <?php else: ?> value="<?php echo e(old('modeloTipoCarroceria')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="modeloFabricante" class="form-label"> <?php echo e(__('strings.fabricante_header')); ?></label>
                        <input id="modeloFabricante" name="modeloFabricante" type="text" placeholder="<?php echo e(__('strings.fabricante_placeholder')); ?>"
                        class="form-control" required <?php if(isset($modelo)): ?> value="<?php echo e(old('modeloFabricante', $modelo->fabricante)); ?>" <?php else: ?> value="<?php echo e(old('modeloFabricante')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="modeloPotencia" class="form-label"> <?php echo e(__('strings.potencia_header')); ?></label>
                        <input id="modeloPotencia" name="modeloTipoCarroceria" type="text" placeholder="<?php echo e(__('strings.potencia_placeholder')); ?>"
                        class="form-control" required <?php if(isset($modelo)): ?> value="<?php echo e(old('modeloPotencia', $modelo->potencia)); ?>" <?php else: ?> value="<?php echo e(old('modeloPotencia')); ?>" <?php endif; ?> />
                    </div>
                    <input type="submit" value="<?php if(isset($modelo)): ?> <?php echo e(__('strings.save_btn')); ?> <?php else: ?> <?php echo e(__('strings.create_btn')); ?> <?php endif; ?>" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/modelos/create.blade.php ENDPATH**/ ?>