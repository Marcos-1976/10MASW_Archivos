[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>