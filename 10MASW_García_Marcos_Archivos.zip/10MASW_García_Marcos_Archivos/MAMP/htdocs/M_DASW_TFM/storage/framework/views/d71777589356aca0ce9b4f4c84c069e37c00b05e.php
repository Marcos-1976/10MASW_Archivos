<?php $__env->startSection('title'); ?>
    <?php echo e(__('strings.cliente_index_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1><?php echo e(__('strings.cliente_index_title')); ?></h1>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <a class="header__link btn btn-sm btn-success" href="<?php echo e(route('clientes.create')); ?>"><?php echo e(__('strings.cliente_create_btn')); ?>&nbsp;</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-6">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="clienteDNI" class="form-label"><?php echo e(__('strings.DNI_header')); ?></label>
                        <input id="clienteDNI" name="clienteDNI" class="form-control" value="<?php if(isset($clienteDNI)): ?> <?php echo e($clienteDNI); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_DNI_placeholder')); ?>" />
                        
                        <label for="clienteNombre" class="form-label"><?php echo e(__('strings.nombre_header')); ?></label>
                        <input id="clienteNombre" name="clienteNombre" class="form-control" value="<?php if(isset($clienteNombre)): ?> <?php echo e($clienteNombre); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_nombre_placeholder')); ?>" />

                        <label for="clienteTelefono" class="form-label"><?php echo e(__('strings.telefono_header')); ?></label>
                        <input id="clienteTelefono" name="clienteTelefono" class="form-control" value="<?php if(isset($clienteTelefono)): ?> <?php echo e($clienteTelefono); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_telefono_placeholder')); ?>" />

                        <label for="clienteEmail" class="form-label"><?php echo e(__('strings.email_header')); ?></label>
                        <input id="clienteEmail" name="clienteEmail" class="form-control" value="<?php if(isset($clienteEmail)): ?> <?php echo e($clienteEmail); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_email_placeholder')); ?>" />

                        <label for="clienteFechaNacimiento" class="form-label"><?php echo e(__('strings.fechaNacimiento_header')); ?></label>
                        <input id="clienteFechaNacimiento" name="clienteFechaNacimiento" class="form-control" value="<?php if(isset($clienteFechaNacimiento)): ?> <?php echo e($clienteFechaNacimiento); ?> <?php endif; ?>" placeholder="<?php echo e(__('strings.search_fechaNacimiento_placeholder')); ?>" />
                        
                        <label for="clienteResidencia" class="form-label"><?php echo e(__('strings.residencia_header')); ?></label>
                        <select id="clienteResidencia" name="clienteResidencia" class="form-select">
                            <option value="-1" selected><?php echo e(__('strings.search_residencia_placeholder')); ?></option>
                            <?php $__currentLoopData = $lugars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lugar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($clienteResidencia == $lugar->residencia): ?> 
                                    <option value="<?php echo e($lugar->residencia); ?>" selected><?php echo e($lugar->residencia); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($lugar->residencia); ?>"><?php echo e($lugar->residencia); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        <button type="submit" class="btn btn-primary my-2"><?php echo e(__('strings.search_btn')); ?></button>
                    </form>
                </div>
                <div class="table-responsive mt-3">
                    <?php if(count($clientes) > 0): ?>
                        <table class="table table-striped align-items-center">
                            <thead class="thead-light">
                                <th><?php echo e(__('strings.DNI_header')); ?></th>
                                <th><?php echo e(__('strings.nombre_header')); ?></th>
                                <th><?php echo e(__('strings.telefono_header')); ?></th>
                                <th><?php echo e(__('strings.email_header')); ?></th>
                                <th><?php echo e(__('strings.fechaNacimiento_header')); ?></th>
                                <th><?php echo e(__('strings.residencia_header')); ?></th>
                                <th><?php echo e(__('strings.actions_header')); ?></th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($cliente->DNI); ?></td> 
                                    <td><?php echo e($cliente->nombre); ?></td>
                                    <td><?php echo e($cliente->telefonoCliente); ?></td>
                                    <td><?php echo e($cliente->eMail); ?></td>
                                    <td><?php echo e($cliente->fechaNacimiento); ?></td>
                                    <td><?php echo e($cliente->lugar->residencia.' - Distrito postal: '.$cliente->lugar->distritoPostal); ?></td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Cliente">
                                            <a class="btn btn-success" href="<?php echo e(route('clientes.edit', $cliente)); ?>"><?php echo e(__('strings.edit_btn')); ?></a>&nbsp;&nbsp;
                                            <form name="delete-form-<?php echo e($cliente->DNI); ?>" action="<?php echo e(route('clientes.delete', $cliente)); ?>" method="post" style="display: inline-block;"> 
                                                <?php echo e(method_field('delete')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger"><?php echo e(__('strings.delete_btn')); ?></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-warning mt-3">
                            <?php echo e(__('strings.no_clientes')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="row my-3 pr-3">
                    <div class="col">
                        <div class="float-right">
                                <?php echo e($clientes->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/clientes/index.blade.php ENDPATH**/ ?>