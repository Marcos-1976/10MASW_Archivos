<?php $__env->startSection('title'); ?>
    <?php echo e(__('strings.cliente_edit_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <h1><?php echo e(__('strings.cliente_edit_title')); ?> <?php echo e($cliente->DNI); ?> <?php echo e($cliente->nombre); ?> <?php echo e($cliente->residencia); ?></h1>
                </div>
            </div>
            <div class="card-body">
                <form name="edit_cliente" action="<?php echo e(route('clientes.update', $cliente)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="clienteDNI" class="form-label"><?php echo e(__('strings.DNI_header')); ?></label>
                        <input id="clienteDNI" name="clienteDNI" type="text" placeholder="<?php echo e(__('strings.DNI_placeholder')); ?>"
                        class="form-control" required value="<?php echo e(old('clienteDNI', $cliente->DNI)); ?>"/>
                        
                        <label for="clienteNombre" class="form-label"><?php echo e(__('strings.nombre_header')); ?></label>
                        <input id="clienteNombre" name="clienteNombre" type="text" placeholder="<?php echo e(__('strings.nombre_placeholder')); ?>"
                        class="form-control" required value="<?php echo e(old('clienteNombre', $cliente->nombre)); ?>"/>

                        <label for="clienteResidencia" class="form-label"><?php echo e(__('strings.residencia_header')); ?></label>
                        <select id="clienteResidencia" name="clienteResidencia" class="form-select">
                            <option value="-1" selected><?php echo e(__('strings.search_residencia_placeholder')); ?></option>
                            <?php $__currentLoopData = $lugars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lugar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($lugar->residencia); ?>" selected><?php echo e($lugar->residencia); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <input type="submit" value="<?php echo e(__('strings.save_btn')); ?>" class="btn btn-primary" name="editBtn"/>
                </form>
            </div>   
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/clientes/edit.blade.php ENDPATH**/ ?>