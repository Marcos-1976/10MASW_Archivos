<?php $__env->startSection('title'); ?>
    <?php if(isset($hatenido)): ?>
        <?php echo e(__('strings.hatenido_edit_title')); ?>

    <?php else: ?>
        <?php echo e(__('strings.hatenido_create_title')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <?php if(isset($hatenido)): ?>
                        <h1><?php echo e(__('strings.hatenido_edit_title')); ?> <?php echo e($hatenido->matricula); ?> <?php echo e($hatenido->idAccidente); ?></h1> 
                    <?php else: ?>
                        <h1><?php echo e(__('strings.hatenido_create_title')); ?></h1>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if(isset($hatenido)): ?>
                    <form name="edit_hatenido" action="<?php echo e(route('hatenidos.update', $hatenido)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php else: ?>
                    <form name="create_hatenido" action="<?php echo e(route('hatenidos.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php endif; ?>
                    <div class="mb-3">
                        <label for="hatenidoMatricula" class="form-label"><?php echo e(__('strings.matricula_header')); ?></label>
                        <select id="hatenidoMatricula" name="hatenidoMatricula" class="form-select">                            
                            <?php if(isset($hatenido)): ?>
                                <option value="-1" selected><?php echo e(__('strings.search_matricula_placeholder')); ?></option>
                                <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($hatenido->matricula == $vehiculo->matricula): ?>     
                                        <option value="<?php echo e($vehiculo->matricula); ?>" selected><?php echo e($vehiculo->matricula); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($vehiculo->matricula); ?>"><?php echo e($vehiculo->matricula); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="-1" selected><?php echo e(__('strings.matricula_placeholder')); ?></option>
                                <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vehiculo->matricula); ?>"><?php echo e($vehiculo->matricula); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="hatenidoIdAccidente" class="form-label"><?php echo e(__('strings.idAccidente_header')); ?></label>
                        <select id="hatenidoIdAccidente" name="hatenidoIdAccidente" class="form-select">                            
                            <?php if(isset($hatenido)): ?>
                                <option value="-1" selected><?php echo e(__('strings.search_idAccidente_placeholder')); ?></option>
                                <?php $__currentLoopData = $accidentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accidente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($hatenido->idAccidente == $accidente->idAccidente): ?>     
                                        <option value="<?php echo e($accidente->idAccidente); ?>" selected><?php echo e($accidente->idAccidente); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($accidente->idAccidente); ?>"><?php echo e($accidente->idAccidente); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="-1" selected><?php echo e(__('strings.idAccidente_placeholder')); ?></option>
                                <?php $__currentLoopData = $accidentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accidente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($accidente->idAccidente); ?>"><?php echo e($accidente->idAccidente); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <input type="submit" value="<?php if(isset($hatenido)): ?> <?php echo e(__('strings.save_btn')); ?> <?php else: ?> <?php echo e(__('strings.create_btn')); ?> <?php endif; ?>" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/hatenidos/create.blade.php ENDPATH**/ ?>