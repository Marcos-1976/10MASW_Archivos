<?php $__env->startSection('title'); ?>
    <?php if(isset($cliente)): ?>
        <?php echo e(__('strings.cliente_edit_title')); ?>

    <?php else: ?>
        <?php echo e(__('strings.cliente_create_title')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-5">
    <div class="col">
        <div class="card shadow">
            <div class="card-header border-0">
                <div class="row">
                    <?php if(isset($cliente)): ?>
                        <h1><?php echo e(__('strings.cliente_edit_title')); ?> <?php echo e($cliente->DNI); ?> <?php echo e($cliente->nombre); ?> <?php echo e($cliente->telefonoCliente); ?> <?php echo e($cliente->eMail); ?> <?php echo e($cliente->fechaNacimiento); ?> <?php echo e($cliente->residencia); ?></h1> 
                    <?php else: ?>
                        <h1><?php echo e(__('strings.cliente_create_title')); ?></h1>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if(isset($cliente)): ?>
                    <form name="edit_cliente" action="<?php echo e(route('clientes.update', $cliente)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php else: ?>
                    <form name="create_cliente" action="<?php echo e(route('clientes.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <?php endif; ?>
                    <div class="mb-3">
                        <label for="clienteDNI" class="form-label"> <?php echo e(__('strings.DNI_header')); ?></label>
                        <input id="clienteDNI" name="clienteDNI" type="text" placeholder="<?php echo e(__('strings.DNI_placeholder')); ?>"
                        class="form-control" required <?php if(isset($cliente)): ?> value="<?php echo e(old('clienteDNI', $cliente->DNI)); ?>" <?php else: ?> value="<?php echo e(old('clienteDNI')); ?>" <?php endif; ?> /> 
                    </div>
                    <div class="mb-3">
                        <label for="clienteNombre" class="form-label"> <?php echo e(__('strings.nombre_header')); ?></label>
                        <input id="clienteNombre" name="clienteNombre" type="text" placeholder="<?php echo e(__('strings.nombre_placeholder')); ?>"
                        class="form-control" required <?php if(isset($cliente)): ?> value="<?php echo e(old('clienteNombre', $cliente->nombre)); ?>" <?php else: ?> value="<?php echo e(old('clienteNombre')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="clienteTelefono" class="form-label"> <?php echo e(__('strings.telefono_header')); ?></label>
                        <input id="clienteTelefono" name="clienteTelefono" type="text" placeholder="<?php echo e(__('strings.telefono_placeholder')); ?>"
                        class="form-control" required <?php if(isset($cliente)): ?> value="<?php echo e(old('clienteTelefono', $cliente->telefonoCliente)); ?>" <?php else: ?> value="<?php echo e(old('clienteTelefono')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="clienteEmail" class="form-label"> <?php echo e(__('strings.email_header')); ?></label>
                        <input id="clienteEmail" name="clienteEmail" type="text" placeholder="<?php echo e(__('strings.email_placeholder')); ?>"
                        class="form-control" required <?php if(isset($cliente)): ?> value="<?php echo e(old('clienteEmail', $cliente->eMail)); ?>" <?php else: ?> value="<?php echo e(old('clienteEmail')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="clienteFechaNacimiento" class="form-label"> <?php echo e(__('strings.fechaNacimiento_header')); ?></label>
                        <input id="clienteFechaNacimiento" name="clienteFechaNacimiento" type="text" placeholder="<?php echo e(__('strings.fechaNacimiento_placeholder')); ?>"
                        class="form-control" required <?php if(isset($cliente)): ?> value="<?php echo e(old('clientefechaNacimiento', $cliente->fechaNacimiento)); ?>" <?php else: ?> value="<?php echo e(old('clienteFechaNacimiento')); ?>" <?php endif; ?> />
                    </div>
                    <div class="mb-3">
                        <label for="clienteResidencia" class="form-label"><?php echo e(__('strings.residencia_header')); ?></label>
                        <select id="clienteResidencia" name="clienteResidencia" class="form-select">                            
                            <?php if(isset($cliente)): ?>
                                <option value="-1" selected><?php echo e(__('strings.search_residencia_placeholder')); ?></option>
                                <?php $__currentLoopData = $lugars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lugar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cliente->residencia == $lugar->residencia): ?>     
                                        <option value="<?php echo e($lugar->residencia); ?>" selected><?php echo e($lugar->residencia); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($lugar->residencia); ?>"><?php echo e($lugar->residencia); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="-1" selected><?php echo e(__('strings.residencia_placeholder')); ?></option>
                                <?php $__currentLoopData = $lugars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lugar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lugar->residencia); ?>"><?php echo e($lugar->residencia); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <input type="submit" value="<?php if(isset($cliente)): ?> <?php echo e(__('strings.save_btn')); ?> <?php else: ?> <?php echo e(__('strings.create_btn')); ?> <?php endif; ?>" class="btn btn-primary" name="createBtn"/>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\M_DASW_TFM\resources\views/clientes/create.blade.php ENDPATH**/ ?>