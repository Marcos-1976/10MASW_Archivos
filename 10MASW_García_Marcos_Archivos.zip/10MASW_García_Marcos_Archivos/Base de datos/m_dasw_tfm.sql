-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 09-05-2023 a las 08:15:12
-- Versión del servidor: 5.7.24
-- Versión de PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `m_dasw_tfm`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accidentes`
--

CREATE TABLE `accidentes` (
  `idAccidente` int(11) NOT NULL,
  `fechaAccidente` date NOT NULL,
  `lugarAccidente` varchar(50) NOT NULL,
  `porcentajeDanio` int(11) NOT NULL,
  `coberturaSiniestro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `accidentes`
--

INSERT INTO `accidentes` (`idAccidente`, `fechaAccidente`, `lugarAccidente`, `porcentajeDanio`, `coberturaSiniestro`) VALUES
(1, '2020-07-04', 'Carretera N-232 KM 68', 25, 30000),
(2, '2022-06-09', 'Autopista AP-2 KM 124', 10, 100000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aseguras`
--

CREATE TABLE `aseguras` (
  `DNI` varchar(9) NOT NULL,
  `matricula` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `aseguras`
--

INSERT INTO `aseguras` (`DNI`, `matricula`) VALUES
('34567876F', '2345BGX'),
('89456787Q', '8945HDH'),
('23456578X', '1111ABC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `DNI` varchar(9) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `telefonoCliente` varchar(12) NOT NULL,
  `eMail` varchar(20) NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `residencia` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`DNI`, `nombre`, `telefonoCliente`, `eMail`, `fechaNacimiento`, `residencia`) VALUES
('23456578X', 'Joan Zaldivar', '+34688456789', 'joan@aol.com', '1976-02-02', 'Avenida Cuarta 47 5B Guadalajara'),
('25657890G', 'Mario García', '+34699456789', 'mario@gmail.com', '1969-10-11', 'Calle La cuesta 34 7C Valencia'),
('34567876F', 'Juan Palomo', '+34123456789', 'juan@hotmail.com', '1985-12-05', 'Calle La cuesta 5 5A Valencia'),
('43456578Z', 'Ayleen Zaldivar', '+56999456789', 'ayleen@aol.com', '1999-01-01', 'Avenida Cuarta 47 5B Guadalajara'),
('84567876T', 'Marta Palomo', '+34987654321', 'marta@hotmail.com', '1990-06-06', 'Calle La cuesta 5 5A Valencia'),
('89456787Q', 'Carlos Zafra', '+54155556789', 'carlos@gmail.com', '1978-02-05', 'Calle Caminito 25 Jaén');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `DNI` varchar(9) NOT NULL,
  `idPoliza` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `compras`
--

INSERT INTO `compras` (`DNI`, `idPoliza`) VALUES
('34567876F', 1),
('23456578X', 3),
('89456787Q', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hatenidos`
--

CREATE TABLE `hatenidos` (
  `matricula` varchar(7) NOT NULL,
  `idAccidente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `hatenidos`
--

INSERT INTO `hatenidos` (`matricula`, `idAccidente`) VALUES
('2345BGX', 1),
('1111ABC', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lugars`
--

CREATE TABLE `lugars` (
  `residencia` varchar(50) NOT NULL,
  `distritoPostal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `lugars`
--

INSERT INTO `lugars` (`residencia`, `distritoPostal`) VALUES
('Avenida Cuarta 47 5B Guadalajara', 19995),
('Calle Caminito 25 Jaén', 23357),
('Calle La cuesta 34 7C Valencia', 45765),
('Calle La cuesta 5 5A Valencia', 45765);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelos`
--

CREATE TABLE `modelos` (
  `idModelo` varchar(20) NOT NULL,
  `tipoCarroceria` varchar(20) NOT NULL,
  `fabricante` varchar(20) NOT NULL,
  `potencia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `modelos`
--

INSERT INTO `modelos` (`idModelo`, `tipoCarroceria`, `fabricante`, `potencia`) VALUES
('Corsa 1998', 'Compacto', 'Opel', 60),
('Focus 2005', 'Sedán', 'Ford', 100),
('Testarossa 2016', 'Deportivo', 'Ferrari', 300);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('test@campusviu.es', '$2y$10$LP6F1T4B/7A/uqWpjO8yUu6WKlQfL1ozpkGqDQPNWtlITaZhcVJwS', '2023-04-26 09:59:02'),
('mf_zgz@hotmail.com', '$2y$10$a24LQYkrA8jvl57g4iuGrejZUJUxWBqPt9lBcJMnlp60ftRYrGi.y', '2023-04-26 10:19:51');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `polizas`
--

CREATE TABLE `polizas` (
  `idPoliza` int(11) NOT NULL,
  `prima` int(11) NOT NULL,
  `fechaAlta` date NOT NULL,
  `fechaVencimiento` date NOT NULL,
  `tipoPoliza` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `polizas`
--

INSERT INTO `polizas` (`idPoliza`, `prima`, `fechaAlta`, `fechaVencimiento`, `tipoPoliza`) VALUES
(1, 500, '2019-04-05', '2022-04-05', 'Small'),
(2, 1500, '2018-12-05', '2021-12-05', 'Small'),
(3, 2800, '2021-10-12', '2024-10-12', 'Premium');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(4, 'Marcos', 'mf_zgz@hotmail.com', NULL, '$2y$10$34x0QT9lhScVzcY1dfdgouyqOtyMk9Ry3T26TFMn1ZUt2UHMn9oYW', NULL, '2023-04-26 10:17:37', '2023-04-26 10:17:37'),
(5, 'Marcos', 'test@campusviu.es', NULL, '$2y$10$XlmizCWekYuqa3b1MXAA3uoNXLTNR2tUGaj4p9dltu1dQ/ENYPgi2', NULL, '2023-05-07 20:59:38', '2023-05-07 20:59:38');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculos`
--

CREATE TABLE `vehiculos` (
  `matricula` varchar(8) NOT NULL,
  `fechaMatricula` date NOT NULL,
  `color` varchar(10) NOT NULL,
  `precio` int(11) NOT NULL,
  `kilometraje` int(11) NOT NULL,
  `antecedentes` varchar(50) NOT NULL,
  `idModelo` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `vehiculos`
--

INSERT INTO `vehiculos` (`matricula`, `fechaMatricula`, `color`, `precio`, `kilometraje`, `antecedentes`, `idModelo`) VALUES
('1111ABC', '2000-02-03', 'Verde', 8000, 340000, 'Ninguno', 'Corsa 1998'),
('2345BGX', '2008-07-12', 'Verde', 35000, 100000, 'Ninguno', 'Focus 2005'),
('8945HDH', '2018-05-23', 'Rojo', 380000, 8000, '3 averías', 'Testarossa 2016');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `accidentes`
--
ALTER TABLE `accidentes`
  ADD PRIMARY KEY (`idAccidente`);

--
-- Indices de la tabla `aseguras`
--
ALTER TABLE `aseguras`
  ADD KEY `DNI_ca` (`DNI`),
  ADD KEY `matricula_ca` (`matricula`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`DNI`),
  ADD KEY `residencia_ca` (`residencia`);

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD KEY `DNI_ca2` (`DNI`),
  ADD KEY `idPoliza_ca` (`idPoliza`);

--
-- Indices de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `hatenidos`
--
ALTER TABLE `hatenidos`
  ADD KEY `matricula_ca2` (`matricula`),
  ADD KEY `idAccidente_ca` (`idAccidente`);

--
-- Indices de la tabla `lugars`
--
ALTER TABLE `lugars`
  ADD PRIMARY KEY (`residencia`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `modelos`
--
ALTER TABLE `modelos`
  ADD PRIMARY KEY (`idModelo`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `polizas`
--
ALTER TABLE `polizas`
  ADD PRIMARY KEY (`idPoliza`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indices de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD PRIMARY KEY (`matricula`),
  ADD KEY `idModelo_ca` (`idModelo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `accidentes`
--
ALTER TABLE `accidentes`
  MODIFY `idAccidente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `polizas`
--
ALTER TABLE `polizas`
  MODIFY `idPoliza` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `aseguras`
--
ALTER TABLE `aseguras`
  ADD CONSTRAINT `DNI_ca` FOREIGN KEY (`DNI`) REFERENCES `clientes` (`DNI`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `matricula_ca` FOREIGN KEY (`matricula`) REFERENCES `vehiculos` (`matricula`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `residencia_ca` FOREIGN KEY (`residencia`) REFERENCES `lugars` (`residencia`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `DNI_ca2` FOREIGN KEY (`DNI`) REFERENCES `clientes` (`DNI`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `idPoliza_ca` FOREIGN KEY (`idPoliza`) REFERENCES `polizas` (`idPoliza`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `hatenidos`
--
ALTER TABLE `hatenidos`
  ADD CONSTRAINT `idAccidente_ca` FOREIGN KEY (`idAccidente`) REFERENCES `accidentes` (`idAccidente`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `matricula_ca2` FOREIGN KEY (`matricula`) REFERENCES `vehiculos` (`matricula`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD CONSTRAINT `idModelo_ca` FOREIGN KEY (`idModelo`) REFERENCES `modelos` (`idModelo`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
