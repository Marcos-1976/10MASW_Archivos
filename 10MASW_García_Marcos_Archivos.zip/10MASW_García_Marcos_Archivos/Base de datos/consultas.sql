# CONSULTAS en phpMyAdmin:

# Listar todos los datos de cada tabla:

SELECT *
FROM clientes;
SELECT *
FROM lugars;
SELECT *
FROM modelos;
SELECT *
FROM vehiculos;
SELECT *
FROM polizas;
SELECT *
FROM accidentes;
SELECT *
FROM aseguras;
SELECT *
FROM compras;
SELECT *
FROM hatenidos;

# Listar todas las filas de la columna que cumplan una condición.
# "Nombre" del cliente que tiene como "DNI" "34567876F":
SELECT nombre
FROM clientes
WHERE DNI = '34567876F';
# "Residencias" que tienen como "código postal" "45765":
SELECT residencia
FROM lugars
WHERE distritoPostal = '45765';

# Listar todas las filas de la columna y el resultado se ordene según una columna.
# Listado de todas las "residencias" ordenadas por "código postal":
SELECT residencia, distritoPostal
FROM lugars
ORDER BY distritoPostal;

# CONSULTAS CON JOIN

# Unir 2 tablas a través de un campo común.
# Listado de la unión de las tablas "clientes" y "aseguras":
SELECT *
FROM clientes INNER JOIN aseguras
	ON cliente.DNI=asegura.DNI;

# Añadiendo una restricción a la consulta.
# Listado de la unión de las tablas "vehiculos" y "modelos" que sea "Focus 2005":
SELECT *
FROM vehiculos JOIN modelos
ON vehiculo.idModelo=modelo.idModelo
WHERE vehiculos.idModelo = 'Focus 2005';

# CONSULTAS CON OPERADORES DE AGREGACIÓN (COUNT, MAX, ...)

# Valor máximo de un atributo o columna.
# Valor del seguro o "prima" "máxima" vendida:
SELECT MAX(prima)
FROM polizas;

# Número total de elementos de un atributo o columna.
# Cantidad de "clientes" totales:
SELECT COUNT(DNI)
FROM clientes;

# Especificando una condición de selección para un grupo utilizando un agregado que se compara con un valor.
# “Precios” de “vehículos” superior a "10000" €:

SELECT precio
FROM vehiculos
GROUP BY precio
HAVING precio >= 10000;
