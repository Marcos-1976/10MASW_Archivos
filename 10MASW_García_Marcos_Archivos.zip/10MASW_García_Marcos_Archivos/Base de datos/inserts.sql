# Introducción de datos en las tablas en phpMyAdmin:

INSERT INTO lugars
VALUES
	('Calle La cuesta 5 5A Valencia', 45765),
	('Calle Caminito 25 Jaén', 23357),
	('Avenida Cuarta 47 5B Guadalajara', 19995),
	('Calle La cuesta 34 7C Valencia', 45765);

INSERT INTO clientes
VALUES
	('34567876F', 'Juan Palomo', '+34123456789', 'juan@hotmail.com', '1985-12-05', 'Calle La cuesta 5 5A Valencia'),
('84567876T', 'Marta Palomo', '+34987654321', 'marta@hotmail.com', '1990-06-06', 'Calle La cuesta 5 5A Valencia'),
	('89456787Q', 'Carlos Zafra', '+54155556789', 'carlos@gmail.com', '1978-02-05', 'Calle Caminito 25 Jaén'),
	('43456578X', 'Ayleen Zaldivar', '+56999456789', 'ayleen@aol.com', '1999-01-01', 'Avenida Cuarta 47 5B Guadalajara'),
('23456578X', 'Joan Zaldivar', '+34688456789', 'joan@aol.com', '1976-02-02', 'Avenida Cuarta 47 5B Guadalajara'),
	('25657890G', 'Mario García', '+34699456789', 'mario@gmail.com', '1969-10-11', 'Calle La cuesta 34 7C Valencia');

INSERT INTO modelos
VALUES
	('Focus 2005', 'Sedán', 'Ford', 100),
	('Testarossa 2016', 'Deportivo', 'Ferrari', 300),
	('Corsa 1998', 'Compacto', 'Opel', 60);

INSERT INTO vehiculos
VALUES
	('2345BGX', '2008-07-12', 'Verde', 35000, 100000, 'Ninguno', 'Focus 2005'),
	('8945HDH', '2018-05-23', 'Rojo', 380000, 8000, '3 averías', 'Testarossa 2016'),
	('1111ABC', '2000-02-03', 'Verde', 8000, 340000, 'Ninguno', 'Corsa 1998');

INSERT INTO polizas
VALUES
	(1, 500, '2019-04-05', '2022-04-05', 'Small'),
	(2, 1500, '2018-12-05', '2021-12-05', 'Small'),
	(3, 2800, '2021-10-12', '2024-10-12', 'Premium');

INSERT INTO accidentes
VALUES
	(1, '2020-07-04', 'Carretera N-232 KM 68', 25, 30000),
	(2, '2022-06-09', 'Autopista AP-2 KM 124', 10, 100000);

INSERT INTO compras
VALUES
	('34567876F', 1),
	('89456787Q', 2),
	('43456578X', 3);

INSERT INTO aseguras
VALUES
	('34567876F', '2345BGX'),
	('89456787Q', '8945HDH'),
	('43456578X', '1111ABC');

INSERT INTO hatenidos
VALUES
	('2345BGX', 1),
	('1111ABC', 2)
