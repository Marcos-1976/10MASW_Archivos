# Eliminación y posterior creación de las tablas en phpMyAdmin:

DROP TABLE IF EXISTS aseguras;
DROP TABLE IF EXISTS compras;
DROP TABLE IF EXISTS hatenidos;
DROP TABLE IF EXISTS clientes;
DROP TABLE IF EXISTS vehiculos;
DROP TABLE IF EXISTS lugars;
DROP TABLE IF EXISTS modelos;
DROP TABLE IF EXISTS polizas;
DROP TABLE IF EXISTS accidentes;

CREATE TABLE lugars (
	residencia VARCHAR(50) NOT NULL,
	distritoPostal INT NOT NULL,
	CONSTRAINT residencia_cp PRIMARY KEY(residencia)
);

CREATE TABLE clientes (
	DNI VARCHAR(9) NOT NULL,
	nombre VARCHAR(20) NOT NULL,
	telefonoCliente VARCHAR(12) NOT NULL,
	eMail VARCHAR(20) NOT NULL,
	fechaNacimiento DATE NOT NULL,
	residencia VARCHAR(50) NOT NULL,
	CONSTRAINT DNI_cp PRIMARY KEY(DNI),
	CONSTRAINT residencia_ca FOREIGN KEY(residencia)
		REFERENCES lugars(residencia) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE modelos (
	idModelo VARCHAR(20) NOT NULL,
	tipoCarroceria VARCHAR(20) NOT NULL,
 	fabricante VARCHAR(20) NOT NULL,
	potencia INT NOT NULL,
	CONSTRAINT idModelo_cp PRIMARY KEY(idModelo)
);

CREATE TABLE vehiculos (
	matricula VARCHAR(8) NOT NULL,
	fechaMatricula DATE NOT NULL,
	color VARCHAR(10) NOT NULL,
	precio INT NOT NULL,
	kilometraje INT NOT NULL,
	antecedentes VARCHAR(50) NOT NULL,
	idModelo VARCHAR(20) NOT NULL,
	CONSTRAINT matricula_cp PRIMARY KEY(matricula),
	CONSTRAINT idModelo_ca FOREIGN KEY(idModelo)
		REFERENCES modelos(idModelo) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE polizas (
	idPoliza INT AUTO_INCREMENT NOT NULL,
 	prima INT NOT NULL,
 	fechaAlta DATE NOT NULL,
	fechaVencimiento DATE NOT NULL,
	tipoPoliza VARCHAR(10) NOT NULL,
	CONSTRAINT idPoliza_cp PRIMARY KEY(idPoliza)
);

CREATE TABLE accidentes (
	idAccidente INT AUTO_INCREMENT NOT NULL,
 	fechaAccidente DATE NOT NULL,
lugarAccidente VARCHAR(50) NOT NULL,
	porcentajeDanio INT NOT NULL,
	coberturaSiniestro INT NOT NULL,
	CONSTRAINT idAccidente_cp PRIMARY KEY(idAccidente)
);

CREATE TABLE aseguras (
	DNI VARCHAR(9) NOT NULL,
	matricula VARCHAR(7) NOT NULL,
	CONSTRAINT DNI_ca FOREIGN KEY(DNI)
		REFERENCES clientes(DNI) ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT matricula_ca FOREIGN KEY(matricula)
		REFERENCES vehiculos(matricula) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE compras (
	DNI VARCHAR(9) NOT NULL,
	idPoliza INT NOT NULL,
	CONSTRAINT DNI_ca2 FOREIGN KEY(DNI)
		REFERENCES clientes(DNI) ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT idPoliza_ca FOREIGN KEY(idPoliza)
		REFERENCES polizas(idPoliza) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE hatenidos (
	matricula VARCHAR(7) NOT NULL,
	idAccidente INT NOT NULL,
	CONSTRAINT matricula_ca2 FOREIGN KEY(matricula)
		REFERENCES vehiculos(matricula) ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT idAccidente_ca FOREIGN KEY(idAccidente)
		REFERENCES accidentes(idAccidente) ON UPDATE CASCADE ON DELETE CASCADE
);
